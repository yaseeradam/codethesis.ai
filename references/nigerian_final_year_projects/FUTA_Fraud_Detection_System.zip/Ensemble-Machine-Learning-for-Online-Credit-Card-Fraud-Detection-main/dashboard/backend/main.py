"""
dashboard/backend/main.py
FastAPI backend for the Credit Card Fraud Detection dashboard.

Endpoints
---------
GET  /health           — Health check (always available, even if model not loaded)
POST /predict          — Predict fraud probability for a single transaction
GET  /explain/{index}  — Return SHAP explanation for a transaction by index
WS   /ws/stream        — WebSocket demo stream using sample rows (not live network traffic)
"""

from __future__ import annotations

import logging
import os
import asyncio
import json
import time
import hashlib
import hmac
from contextlib import asynccontextmanager
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
import shap
import joblib
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect, Request, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Paths (resolved relative to the repo root — adjust as needed)
# ---------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
MODEL_PATH = os.path.join(BASE_DIR, "results", "stacking_model.pkl")
SCALER_PATH = os.path.join(BASE_DIR, "results", "stacking_model.pkl")  # scaler embedded in model bundle
DATA_PATH = os.path.join(BASE_DIR, "data", "creditcard.csv")

# ---------------------------------------------------------------------------
# Application state — populated in lifespan, may be None if files are missing
# ---------------------------------------------------------------------------
class AppState:
    model: Optional[Any] = None
    scaler: Optional[Any] = None
    data: Optional[pd.DataFrame] = None
    explainer: Optional[Any] = None
    model_loaded: bool = False


state = AppState()

# ---------------------------------------------------------------------------
# Lifespan — graceful degradation if artefacts are absent
# ---------------------------------------------------------------------------
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Load ML artefacts at startup; degrade gracefully if any are missing."""
    # --- Model ---
    # Never deserialize a pickle/joblib artifact without a trusted digest.
    if not MODEL_SHA256:
        logger.error("MODEL_SHA256 is not configured; refusing to load model.")
        state.model = None
    elif os.path.exists(MODEL_PATH):
        try:
            if MODEL_SHA256:
                digest = _sha256_file(MODEL_PATH)
                if digest != MODEL_SHA256:
                    raise RuntimeError("MODEL_SHA256 integrity check failed")
            state.model = joblib.load(MODEL_PATH)
            if not isinstance(state.model, dict):
                raise RuntimeError("Invalid model bundle schema: expected a dictionary")
            required_keys = {"base_learners", "meta_learner", "feature_names", "feature_schema_version"}
            missing_keys = required_keys - set(state.model)
            if state.model.get("feature_schema_version") != "ulb-pca-elapsed-hours-v1":
                raise RuntimeError(
                    "Unsupported feature schema: regenerate the model using the current elapsed-hours contract."
                )
            pipeline_preprocessing = bool(state.model.get("preprocessing_in_estimators", False))
            legacy_scaler_available = state.model.get("scaler") is not None
            if missing_keys or not (pipeline_preprocessing or legacy_scaler_available):
                raise RuntimeError(
                    f"Invalid model bundle schema: missing={sorted(missing_keys)}, "
                    "or no supported preprocessing strategy is declared"
                )
            logger.info("Model loaded from %s", MODEL_PATH)
        except Exception as exc:
            logger.warning("Failed to load model from %s: %s", MODEL_PATH, exc)
            state.model = None
    else:
        logger.warning(
            "Model file not found at %s. Prediction endpoints will return 503. "
            "Run scripts/create_demo_model.py to generate it.",
            MODEL_PATH,
        )

    state.scaler = state.model.get("scaler") if isinstance(state.model, dict) else None

    # --- Dashboard data ---
    if os.path.exists(DATA_PATH):
        try:
            state.data = pd.read_csv(DATA_PATH)
            logger.info("Dataset loaded: %d rows from %s", len(state.data), DATA_PATH)
        except Exception:
            state.data = _generate_dashboard_data()
    else:
        state.data = _generate_dashboard_data()
        logger.info("Research dataset absent; using synthetic dashboard data.")

    # Build explanations against the exact engineered feature space expected by the bundle.
    if state.model is not None and state.data is not None:
        try:
            background = _prepare_raw_dataframe(state.data).sample(
                min(50, len(state.data)), random_state=42
            )
            state.explainer = shap.Explainer(
                lambda matrix: _predict_matrix(np.asarray(matrix)),
                background.to_numpy(dtype=float),
                feature_names=list(background.columns),
                algorithm="permutation",
            )
            logger.info("SHAP explainer initialised.")
        except Exception as exc:
            logger.warning("Could not initialise SHAP explainer: %s", exc)
            state.explainer = None
    state.model_loaded = state.model is not None
    logger.info("Startup complete. model_loaded=%s", state.model_loaded)

    yield  # ← application runs here

    # Shutdown
    logger.info("Shutting down.")


# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------
ALLOWED_ORIGINS: List[str] = [x.strip() for x in os.environ.get("ALLOWED_ORIGINS", "").split(",") if x.strip()]
API_KEY = os.environ.get("FRAUD_API_KEY", "").strip()
RATE_LIMIT_PER_MINUTE = int(os.environ.get("RATE_LIMIT_PER_MINUTE", "120"))
MAX_WS_CONNECTIONS_PER_IP = int(os.environ.get("MAX_WS_CONNECTIONS_PER_IP", "3"))
_ws_connections: Dict[str, int] = {}
MODEL_SHA256 = os.environ.get("MODEL_SHA256", "").strip().lower()
_rate_buckets: Dict[str, List[float]] = {}

app = FastAPI(
    title="Fraud Detection API",
    description="Ensemble ML-based credit card fraud detection backend.",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type", "X-API-Key"],
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _sha256_file(path: str, chunk_size: int = 1024 * 1024) -> str:
    """Hash model artifacts incrementally before deserializing them."""
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        for chunk in iter(lambda: stream.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _get_feature_columns(df: pd.DataFrame) -> List[str]:
    """Return feature columns (all except 'Class')."""
    return [c for c in df.columns if c != "Class"]


def _require_model() -> None:
    """Raise 503 if the model is not loaded."""
    if state.model is None:
        raise HTTPException(
            status_code=503,
            detail=(
                "Model is not loaded. Supply a verified trained model bundle before live use."
            ),
        )


def _require_api_key(provided_key: Optional[str]) -> None:
    production_mode = os.environ.get("APP_ENV", "development").strip().lower() in {"production", "prod"}
    if production_mode and not API_KEY:
        raise HTTPException(
            status_code=503,
            detail="Authentication is not configured. Set FRAUD_API_KEY before production startup.",
        )
    if API_KEY and not hmac.compare_digest(provided_key or "", API_KEY):
        raise HTTPException(status_code=401, detail="Invalid or missing API key.")


def _check_rate_limit(request: Request) -> None:
    now = time.monotonic()
    key = request.client.host if request.client else "unknown"
    bucket = [t for t in _rate_buckets.get(key, []) if now - t < 60]
    if len(bucket) >= RATE_LIMIT_PER_MINUTE:
        raise HTTPException(status_code=429, detail="Rate limit exceeded. Try again later.")
    bucket.append(now)
    _rate_buckets[key] = bucket
    if len(_rate_buckets) > 10000:
        oldest = min(_rate_buckets, key=lambda k: _rate_buckets[k][-1])
        _rate_buckets.pop(oldest, None)


def _safe_expected_value(explainer: Any) -> float:
    """
    Safely extract the scalar expected value from a SHAP explainer.

    XGBoost binary classifiers may return:
      - a float                   -> use directly
      - a list / np.ndarray       -> take the last element (positive class)
      - a nested list/array       -> flatten and take the last element

    Returns a plain Python float in all cases.
    """
    ev = explainer.expected_value

    if isinstance(ev, (int, float)):
        return float(ev)

    # Convert to a flat numpy array for uniform handling
    ev_arr = np.asarray(ev).flatten()

    if ev_arr.size == 0:
        return 0.0
    if ev_arr.size == 1:
        return float(ev_arr[0])

    # Multi-class or binary: return the last element (positive class)
    return float(ev_arr[-1])


# ---------------------------------------------------------------------------
# Model/data adapters
# ---------------------------------------------------------------------------

def _generate_dashboard_data(n_samples: int = 500, random_state: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(random_state)
    values = rng.standard_normal((n_samples, 28))
    amount = rng.lognormal(3.5, 1.4, n_samples).clip(0, 25000)
    times = rng.uniform(0, 172792, n_samples)
    score = -0.8 * values[:, 13] - 0.6 * values[:, 11] - 0.5 * values[:, 9]
    labels = (score + rng.normal(0, 1, n_samples) >= np.quantile(score, 0.95)).astype(int)
    frame = pd.DataFrame(values, columns=[f"V{i}" for i in range(1, 29)])
    frame["Amount"] = amount
    frame["Time"] = times
    frame["Class"] = labels
    return frame


def _prepare_raw_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    required = [f"V{i}" for i in range(1, 29)] + ["Amount", "Time"]
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError(f"Dataset is missing required columns: {missing}")
    out = df[required].copy()
    out["Amount_log"] = np.log1p(out["Amount"].astype(float))
    # ULB Time is elapsed seconds from the first transaction, not clock time.
    out["Hour"] = out["Time"].astype(float) / 3600.0
    feature_names = list(state.model.get("feature_names", []))
    return out[feature_names]


def _predict_matrix(matrix: np.ndarray) -> np.ndarray:
    """Predict using either a current pipeline bundle or a legacy demo bundle."""
    feature_names = list(state.model["feature_names"])
    frame = pd.DataFrame(matrix, columns=feature_names)
    if state.model.get("preprocessing_in_estimators", False):
        model_input = frame
    else:
        scaler = state.model.get("scaler")
        if scaler is None:
            raise RuntimeError("Legacy model bundle is missing its scaler.")
        model_input = scaler.transform(frame)

    meta_features = np.column_stack([
        learner.predict_proba(model_input)[:, 1]
        for learner in state.model["base_learners"]
    ])
    return state.model["meta_learner"].predict_proba(meta_features)[:, 1]


def _predict_raw(df: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
    probabilities = _predict_matrix(_prepare_raw_dataframe(df).to_numpy(dtype=float))
    threshold = float(state.model.get("optimal_threshold", 0.5))
    return probabilities, (probabilities >= threshold).astype(int)


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------

class TransactionFeatures(BaseModel):
    """Input schema for /predict.

    Accepts a dictionary of feature names to values.  The canonical feature
    set is V1–V28 plus Amount and Time (30 features total).
    """
    features: Dict[str, float]


class PredictionResponse(BaseModel):
    fraud_probability: float
    prediction: int
    threshold: float
    model_loaded: bool


class HealthResponse(BaseModel):
    status: str
    model_loaded: bool
    model_version: str
    readiness: bool


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.get("/health", response_model=HealthResponse, tags=["system"])
async def health_check() -> HealthResponse:
    """
    Readiness health check.
    Reports whether the model is currently loaded.
    """
    version = "unknown"
    if isinstance(state.model, dict):
        version = str(state.model.get("model_version", "unknown"))
    if not state.model_loaded:
        raise HTTPException(
            status_code=503,
            detail={
                "status": "unready",
                "model_loaded": False,
                "model_version": version,
                "readiness": False,
            },
        )
    return HealthResponse(
        status="ok",
        model_loaded=True,
        model_version=version,
        readiness=True,
    )


@app.post("/predict", response_model=PredictionResponse, tags=["inference"])
async def predict(transaction: TransactionFeatures, request: Request, x_api_key: Optional[str] = Header(default=None, alias="X-API-Key")) -> PredictionResponse:
    """
    Predict the fraud probability for a single transaction.

    The ``features`` dict should contain all 30 feature keys
    (V1–V28, Amount, Time).  Feature order is inferred from the model's
    ``feature_names_in_`` attribute when available.
    """
    _require_model()
    _require_api_key(x_api_key)
    _check_rate_limit(request)

    try:
        feature_dict = transaction.features
        required = [f"V{i}" for i in range(1, 29)] + ["Amount", "Time"]
        missing = [name for name in required if name not in feature_dict]
        if missing:
            raise HTTPException(status_code=422, detail={"missing_features": missing})
        unknown = sorted(set(feature_dict) - set(required))
        if unknown:
            raise HTTPException(status_code=422, detail={"unknown_features": unknown})
        if not all(np.isfinite(float(v)) for v in feature_dict.values()):
            raise HTTPException(status_code=422, detail="All feature values must be finite numbers.")
        if float(feature_dict["Amount"]) < 0 or float(feature_dict["Time"]) < 0:
            raise HTTPException(status_code=422, detail="Amount and Time must be non-negative.")

        row = dict(feature_dict)
        row["Amount_log"] = float(np.log1p(row["Amount"]))
        row["Hour"] = float(row["Time"] / 3600.0)
        expected_cols = list(state.model.get("feature_names", []))
        df_input = pd.DataFrame([{col: row[col] for col in expected_cols}], columns=expected_cols)
        proba = float(_predict_matrix(df_input.to_numpy(dtype=float))[0])
        threshold = float(state.model.get("optimal_threshold", 0.5))
        pred = int(proba >= threshold)

        return PredictionResponse(
            fraud_probability=proba,
            prediction=pred,
            threshold=threshold,
            model_loaded=True,
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Prediction failed: %s", exc)
        raise HTTPException(status_code=500, detail=f"Prediction error: {exc}") from exc


@app.get("/explain/{index}", tags=["inference"])
async def explain(
    index: int,
    request: Request,
    x_api_key: Optional[str] = Header(default=None, alias="X-API-Key"),
) -> Dict[str, Any]:
    """Return a SHAP explanation using the same protected inference path as /predict."""
    _require_model()
    _require_api_key(x_api_key)
    _check_rate_limit(request)
    if state.data is None:
        raise HTTPException(status_code=503, detail="Dashboard dataset is unavailable.")
    if state.explainer is None:
        raise HTTPException(status_code=503, detail="SHAP explainer is not initialised.")
    if index < 0 or index >= len(state.data):
        raise HTTPException(status_code=404, detail=f"Index {index} out of range.")

    try:
        raw_row = state.data.iloc[[index]]
        engineered = _prepare_raw_dataframe(raw_row)
        shap_values = state.explainer(engineered.to_numpy(dtype=float))
        sv = np.asarray(shap_values.values)
        if sv.ndim > 2:
            sv = sv[..., -1]
        base_values = np.asarray(shap_values.base_values).reshape(-1)
        expected_value = float(base_values[-1]) if base_values.size else 0.0
        probabilities, predictions = _predict_raw(raw_row)
        return {
            "index": index,
            "feature_names": list(engineered.columns),
            "features": list(engineered.columns),  # Backward-compatible field used by the dashboard/tests.
            "shap_values": sv[0].tolist(),
            "expected_value": expected_value,
            "prediction": int(predictions[0]),
            "fraud_probability": float(probabilities[0]),
        }
    except HTTPException:
        raise
    except Exception:
        logger.exception("Explain failed for index %d", index)
        raise HTTPException(status_code=500, detail="Explanation generation failed.")


# ---------------------------------------------------------------------------
# WebSocket — sample transaction replay (demo only)
# ---------------------------------------------------------------------------

@app.websocket("/ws/stream")
async def websocket_stream(websocket: WebSocket) -> None:
    """
    Replay labelled sample rows through the research model (demo only).

    The client controls start/stop and replay interval using JSON messages.
    This endpoint is not connected to a live payment network or event feed.
    """
    origin = websocket.headers.get("origin")
    if origin and ALLOWED_ORIGINS and origin not in ALLOWED_ORIGINS:
        await websocket.close(code=1008, reason="Origin is not allowed.")
        return

    client_ip = websocket.client.host if websocket.client else "unknown"
    active_connections = _ws_connections.get(client_ip, 0)
    if active_connections >= MAX_WS_CONNECTIONS_PER_IP:
        await websocket.close(code=1013, reason="Too many replay connections.")
        return

    production_mode = os.environ.get("APP_ENV", "development").strip().lower() in {"production", "prod"}
    if production_mode and not API_KEY:
        await websocket.close(code=1011, reason="API authentication is not configured.")
        return
    provided_key = websocket.headers.get("x-api-key", "")
    if API_KEY and not hmac.compare_digest(provided_key, API_KEY):
        await websocket.close(code=1008, reason="Invalid or missing API key.")
        return

    _ws_connections[client_ip] = active_connections + 1
    await websocket.accept()
    logger.info("WebSocket sample replay client connected.")
    running = False
    interval_seconds = 1.0

    try:
        while True:
            try:
                message = await asyncio.wait_for(
                    websocket.receive_json(),
                    timeout=interval_seconds if running else None,
                )
                if not isinstance(message, dict):
                    await websocket.send_json({"error": "Control message must be a JSON object."})
                    continue

                action = str(message.get("action", "")).strip().lower()
                if action in {"start", "speed"}:
                    requested_interval = float(message.get("interval", interval_seconds))
                    if not np.isfinite(requested_interval):
                        requested_interval = 1.0
                    interval_seconds = float(np.clip(requested_interval, 0.1, 10.0))
                    running = True
                elif action == "stop":
                    running = False
                else:
                    await websocket.send_json({"error": "Supported actions are start, stop and speed."})
            except asyncio.TimeoutError:
                if not running:
                    continue
                if state.model is None or state.data is None:
                    await websocket.send_json({"error": "Service is not ready", "model_loaded": False})
                    continue

                try:
                    sample = state.data.sample(1, random_state=None)
                    original = sample.iloc[0]
                    feature_columns = [f"V{i}" for i in range(1, 29)] + ["Amount", "Time"]
                    raw_features = {
                        name: float(original[name])
                        for name in feature_columns
                        if name in sample.columns
                    }
                    started = time.perf_counter()
                    probabilities, predictions = _predict_raw(sample)
                    latency_ms = (time.perf_counter() - started) * 1000.0
                    probability = float(probabilities[0])
                    prediction = int(predictions[0])
                    actual = int(original["Class"]) if "Class" in sample.columns else None
                    threshold = float(state.model.get("optimal_threshold", 0.5))
                    risk_level = (
                        "High" if prediction == 1
                        else "Medium" if probability >= threshold * 0.5
                        else "Low"
                    )
                    payload: Dict[str, Any] = {
                        "index": int(sample.index[0]),
                        "transaction_index": int(sample.index[0]),
                        "timestamp": time.time(),
                        "features": raw_features,
                        "fraud_probability": probability,
                        "probability": probability,
                        "prediction": prediction,
                        "actual": actual,
                        "true_label": actual,
                        "threshold": threshold,
                        "risk_level": risk_level,
                        "latency_ms": float(latency_ms),
                        "model_version": str(state.model.get("model_version", "unknown")),
                        "data_source": "synthetic_dashboard_data" if not os.path.exists(DATA_PATH) else "local_csv_replay",
                        "model_training_source": (
                            "synthetic_demo"
                            if "synthetic" in str(state.model.get("training_note", "")).lower()
                            else "research_or_external_dataset"
                        ),
                    }
                    await websocket.send_json(payload)
                except Exception:
                    logger.exception("Sample replay prediction failed.")
                    await websocket.send_json({"error": "Prediction failed"})
    except WebSocketDisconnect:
        logger.info("WebSocket sample replay client disconnected.")
    except Exception:
        logger.exception("WebSocket sample replay crashed.")
    finally:
        remaining = _ws_connections.get(client_ip, 1) - 1
        if remaining > 0:
            _ws_connections[client_ip] = remaining
        else:
            _ws_connections.pop(client_ip, None)
