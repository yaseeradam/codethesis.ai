# API Documentation — ScentMatch Perfume Recommender

Base URL (Production): `https://ai-perfume-recommender-production.up.railway.app`
Base URL (Local): `http://localhost:5000`

---

## Authentication

Protected routes require a JWT token in the Authorization header:

```
Authorization: Bearer <token>
```

Obtain a token by calling `POST /api/auth/login`.

---

## Public Endpoints

### POST /api/recommend

Returns a ranked list of perfume recommendations based on user preferences.

**Request Body:**

```json
{
  "session_id": "unique-session-string",
  "preferences": {
    "accords": ["floral", "woody", "citrus"],
    "gender": "female",
    "price_tier": "moderate",
    "longevity": "moderate",
    "season": "spring"
  },
  "top_n": 10
}
```

**Parameters:**

| Field | Type | Required | Description |
|---|---|---|---|
| session_id | string | Yes | Unique session identifier |
| preferences.accords | string[] | Yes | List of preferred scent families |
| preferences.gender | string | Yes | male / female / unisex |
| preferences.price_tier | string | Yes | budget / moderate / high |
| preferences.longevity | string | Yes | light / moderate / strong |
| preferences.season | string | Yes | spring / summer / fall / winter |
| top_n | number | No | Number of results (default: 10) |

**Available Accords:**
floral, woody, citrus, fresh, oriental, musky, vanilla, gourmand, aquatic, spicy, aromatic, fruity, powdery, amber, leather, green, rose, oud, warm spicy, white floral, and 64 more.

**Response (200 OK):**

```json
{
  "success": true,
  "count": 10,
  "recommendations": [
    {
      "perfume_id": 11437,
      "name": "City Rush For Her",
      "brand": "Avon",
      "price_tier": "moderate",
      "longevity": "moderate",
      "season": "spring",
      "gender": "female",
      "rating_value": "3.96",
      "image_url": "",
      "similarity_score": 77.15,
      "explanation": "Matches your floral, woody scent preference. moderate longevity as preferred. fits your moderate budget."
    }
  ]
}
```

**Response Fields:**

| Field | Type | Description |
|---|---|---|
| perfume_id | number | Unique perfume identifier |
| name | string | Perfume name |
| brand | string | Brand name |
| price_tier | string | budget / moderate / high |
| longevity | string | light / moderate / strong |
| season | string | Best season for the perfume |
| gender | string | Target gender |
| rating_value | string | Average user rating (1-5) |
| similarity_score | number | Match percentage (0-100) |
| explanation | string | Human-readable explanation |

---

### POST /api/auth/login

Authenticates the admin user and returns a JWT token.

**Request Body:**

```json
{
  "username": "admin",
  "password": "admin123"
}
```

**Response (200 OK):**

```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "message": "Login successful"
}
```

**Response (401 Unauthorized):**

```json
{
  "success": false,
  "message": "Invalid credentials"
}
```

---

## Protected Endpoints

All protected endpoints require the Authorization header:
```
Authorization: Bearer <your_token>
```

---

### GET /api/perfumes

Returns a paginated list of all perfumes.

**Query Parameters:**

| Parameter | Type | Default | Description |
|---|---|---|---|
| page | number | 1 | Page number |
| limit | number | 20 | Records per page |
| search | string | "" | Search by name or brand |

**Example Request:**
```
GET /api/perfumes?page=1&limit=20&search=chanel
```

**Response (200 OK):**

```json
{
  "success": true,
  "data": [
    {
      "perfume_id": 1,
      "name": "Chance",
      "brand": "Chanel",
      "country_of_origin": "France",
      "target_gender": "female",
      "price_tier": "high",
      "longevity": "moderate",
      "season_suitability": "spring",
      "rating_value": "4.20",
      "rating_count": 15420,
      "launch_year": 2002,
      "accords": "floral,fresh,powdery"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 23846,
    "pages": 1193
  }
}
```

---

### GET /api/perfumes/:id

Returns a single perfume by ID.

**Example Request:**
```
GET /api/perfumes/1
```

**Response (200 OK):**

```json
{
  "success": true,
  "data": {
    "perfume_id": 1,
    "name": "Chance",
    "brand": "Chanel",
    "country_of_origin": "France",
    "target_gender": "female",
    "price_tier": "high",
    "longevity": "moderate",
    "season_suitability": "spring",
    "rating_value": "4.20",
    "rating_count": 15420,
    "launch_year": 2002,
    "accords": "floral,fresh,powdery"
  }
}
```

**Response (404 Not Found):**

```json
{
  "success": false,
  "message": "Perfume not found"
}
```

---

### POST /api/perfumes

Creates a new perfume record.

**Request Body:**

```json
{
  "name": "My New Perfume",
  "brand": "My Brand",
  "country_of_origin": "France",
  "target_gender": "unisex",
  "price_tier": "moderate",
  "longevity": "strong",
  "season_suitability": "winter",
  "launch_year": 2024,
  "description": "A beautiful fragrance",
  "accords": ["woody", "amber", "spicy"]
}
```

**Required Fields:** name, brand, target_gender

**Response (201 Created):**

```json
{
  "success": true,
  "message": "Perfume created",
  "perfume_id": 23847
}
```

---

### PUT /api/perfumes/:id

Updates an existing perfume record.

**Request Body:** Same as POST (all fields optional except required ones)

**Response (200 OK):**

```json
{
  "success": true,
  "message": "Perfume updated"
}
```

---

### DELETE /api/perfumes/:id

Deletes a perfume record.

**Response (200 OK):**

```json
{
  "success": true,
  "message": "Perfume deleted"
}
```

---

### PUT /api/auth/change-password

Changes the admin password.

**Request Body:**

```json
{
  "current_password": "admin123",
  "new_password": "mynewpassword",
  "confirm_password": "mynewpassword"
}
```

**Response (200 OK):**

```json
{
  "success": true,
  "message": "Password changed successfully"
}
```

**Response (401 Unauthorized):**

```json
{
  "success": false,
  "message": "Current password is incorrect"
}
```

---

## Error Responses

All endpoints return consistent error responses:

```json
{
  "success": false,
  "message": "Description of what went wrong"
}
```

| Status Code | Meaning |
|---|---|
| 400 | Bad Request — missing or invalid fields |
| 401 | Unauthorized — invalid or missing token |
| 404 | Not Found — resource doesn't exist |
| 500 | Internal Server Error — server-side issue |
