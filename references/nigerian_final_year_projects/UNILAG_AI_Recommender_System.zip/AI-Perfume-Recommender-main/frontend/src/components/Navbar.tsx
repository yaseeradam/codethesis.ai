import { useNavigate, useLocation } from 'react-router-dom'
import { isLoggedIn, logout }       from '../utils/auth'
import './Navbar.css'

export default function Navbar() {
  const navigate = useNavigate()
  const location = useLocation()

  const isAdmin = isLoggedIn()

  // Hide navbar on login page
  if (location.pathname === '/admin/login') return null

  return (
    <nav className="navbar">
      <div className="navbar-brand" onClick={() => navigate('/')}>
        🧴 <span>ScentMatch</span>
      </div>

      <div className="navbar-links">
        <button
          className={`nav-link ${location.pathname === '/' ? 'active' : ''}`}
          onClick={() => navigate('/')}
        >
          Home
        </button>
        <button
          className={`nav-link ${location.pathname === '/quiz' ? 'active' : ''}`}
          onClick={() => navigate('/quiz')}
        >
          Find Fragrance
        </button>
        {isAdmin && (
          <button
            className={`nav-link ${location.pathname === '/admin' ? 'active' : ''}`}
            onClick={() => navigate('/admin')}
          >
            Admin
          </button>
        )}
        {isAdmin
          ? (
            <button className="nav-btn-outline" onClick={() => { logout(); navigate('/admin/login') }}>
              Logout
            </button>
          ) : (
            <button className="nav-btn" onClick={() => navigate('/admin/login')}>
              Admin Login
            </button>
          )
        }
      </div>
    </nav>
  )
}