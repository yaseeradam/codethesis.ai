import './RecommendationCard.css'

interface Perfume {
  perfume_id:       number
  name:             string
  brand:            string
  price_tier:       string
  longevity:        string
  season:           string
  gender:           string
  rating_value:     string
  image_url:        string
  similarity_score: number
  explanation:      string
}

interface Props {
  perfume: Perfume
  rank:    number
}

const PRICE_LABELS: Record<string, string>    = { budget: '💰 Budget', moderate: '💳 Moderate', high: '💎 High End' }
const LONGEVITY_LABELS: Record<string, string> = { light: '🌬️ Light', moderate: '⏱️ Moderate', strong: '💪 Long Lasting' }
const SEASON_LABELS: Record<string, string>    = { spring: '🌸 Spring', summer: '☀️ Summer', fall: '🍂 Fall', winter: '❄️ Winter' }
const GENDER_LABELS: Record<string, string>    = { female: '👩 Feminine', male: '👨 Masculine', unisex: '🧑 Unisex' }

function ScoreRing({ score }: { score: number }) {
  const radius      = 28
  const stroke      = 5
  const normalised  = radius - stroke / 2
  const circumference = 2 * Math.PI * normalised
  const offset      = circumference - (score / 100) * circumference

  return (
    <div className="score-ring-wrapper">
      <svg width="70" height="70" viewBox="0 0 70 70">
        <circle cx="35" cy="35" r={normalised} fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth={stroke} />
        <circle
          cx="35" cy="35" r={normalised}
          fill="none"
          stroke="#4d8eff"
          strokeWidth={stroke}
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          transform="rotate(-90 35 35)"
        />
      </svg>
      <div className="score-text">{score}%</div>
    </div>
  )
}

export default function RecommendationCard({ perfume, rank }: Props) {
  return (
    <div className="rec-card">

      {/* Rank badge */}
      <div className={`rank-badge ${rank === 1 ? 'rank-gold' : rank === 2 ? 'rank-silver' : rank === 3 ? 'rank-bronze' : ''}`}>
        #{rank}
      </div>

      {/* Top section */}
      <div className="card-top">
        <div className="card-image">
          {perfume.image_url
            ? <img src={perfume.image_url} alt={perfume.name} />
            : <div className="image-placeholder">🧴</div>
          }
        </div>

        <div className="card-info">
          <p className="card-brand">{perfume.brand}</p>
          <h3 className="card-name">{perfume.name}</h3>
          {perfume.rating_value && (
            <div className="card-rating">
              ⭐ {parseFloat(perfume.rating_value).toFixed(1)}
            </div>
          )}
        </div>

        <ScoreRing score={perfume.similarity_score} />
      </div>

      {/* Tags */}
      <div className="card-tags">
        <span className="tag">{GENDER_LABELS[perfume.gender]    || perfume.gender}</span>
        <span className="tag">{PRICE_LABELS[perfume.price_tier] || perfume.price_tier}</span>
        <span className="tag">{LONGEVITY_LABELS[perfume.longevity] || perfume.longevity}</span>
        <span className="tag">{SEASON_LABELS[perfume.season]    || perfume.season}</span>
      </div>

      {/* Explanation */}
      <div className="card-explanation">
        <span className="explanation-icon">💡</span>
        <p>{perfume.explanation}</p>
      </div>

    </div>
  )
}