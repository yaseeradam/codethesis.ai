import { Navigate } from 'react-router-dom'
import { isLoggedIn } from '../utils/auth'

interface Props {
  children: React.ReactNode
}

export default function ProtectedRoute({ children }: Props) {
  if (!isLoggedIn()) {
    return <Navigate to="/admin/login" replace />
  }
  return <>{children}</>
}