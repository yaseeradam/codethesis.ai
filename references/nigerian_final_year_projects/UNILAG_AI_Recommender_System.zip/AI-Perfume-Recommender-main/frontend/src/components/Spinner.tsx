import './Spinner.css'

interface Props {
  message?: string
}

export default function Spinner({ message = 'Finding your perfect fragrances...' }: Props) {
  return (
    <div className="spinner-overlay">
      <div className="spinner-card">
        <div className="spinner-rings">
          <div className="ring ring-1" />
          <div className="ring ring-2" />
          <div className="ring ring-3" />
          <span className="spinner-emoji">🧴</span>
        </div>
        <p className="spinner-message">{message}</p>
        <p className="spinner-sub">Analysing 23,000+ fragrances with AI...</p>
      </div>
    </div>
  )
}