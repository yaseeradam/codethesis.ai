import { useNavigate } from 'react-router-dom'
import './HomePage.css'

export default function HomePage() {
  const navigate = useNavigate()

  return (
    <div className="home-container">
      <div className="home-content">

        <div className="home-badge">✨ AI-Powered</div>

        <h1 className="home-title">
          Find Your Perfect <span className="highlight">Fragrance</span>
        </h1>

        <p className="home-subtitle">
          Answer a few questions about your scent preferences and our 
          recommendation engine will match you with perfumes from a 
          database of over 23,000 fragrances.
        </p>

        <div className="home-stats">
          <div className="stat">
            <span className="stat-number">23,000+</span>
            <span className="stat-label">Fragrances</span>
          </div>
          <div className="stat-divider" />
          <div className="stat">
            <span className="stat-number">84</span>
            <span className="stat-label">Scent Families</span>
          </div>
          <div className="stat-divider" />
          <div className="stat">
            <span className="stat-number">AI</span>
            <span className="stat-label">Powered</span>
          </div>
        </div>

        <button className="home-btn" onClick={() => navigate('/quiz')}>
          Find My Fragrance →
        </button>

      </div>

      <div className="home-decoration">
        <div className="circle circle-1" />
        <div className="circle circle-2" />
        <div className="circle circle-3" />
        <span className="decoration-emoji">🧴</span>
      </div>
    </div>
  )
}