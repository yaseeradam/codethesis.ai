import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import RecommendationCard from '../components/RecommendationCard'
import './ResultsPage.css'

interface Recommendation {
  perfume_id:       number
  name:             string
  brand:            string
  price_tier:       string
  longevity:        string
  season:           string
  gender:           string
  rating_value:     string
  image_url:        string
  similarity_score: number
  explanation:      string
}

export default function ResultsPage() {
  const navigate = useNavigate()
  const [recommendations, setRecommendations] = useState<Recommendation[]>([])

  useEffect(() => {
    const stored = sessionStorage.getItem('recommendations')
    if (!stored) {
      navigate('/')
      return
    }
    setRecommendations(JSON.parse(stored))
  }, [navigate])

  return (
    <div className="results-container">

      {/* Header */}
      <div className="results-header">
        <div className="results-header-top">
          <button className="back-btn" onClick={() => navigate('/quiz')}>
            ← Retake Quiz
          </button>
          <button className="home-btn" onClick={() => navigate('/')}>
            🏠 Home
          </button>
        </div>

        <div className="results-title-block">
          <div className="results-badge">✨ Your Matches</div>
          <h1 className="results-title">
            We found <span className="highlight">{recommendations.length}</span> fragrances for you
          </h1>
          <p className="results-subtitle">
            Ranked by how closely they match your scent preferences
          </p>
        </div>
      </div>

      {/* Cards */}
      <div className="results-grid">
        {recommendations.map((rec, index) => (
          <RecommendationCard
            key={rec.perfume_id}
            perfume={rec}
            rank={index + 1}
          />
        ))}
      </div>

      {/* Footer CTA */}
      <div className="results-footer">
        <p>Not quite right?</p>
        <button className="retake-btn" onClick={() => navigate('/quiz')}>
          Try Different Preferences
        </button>
      </div>

    </div>
  )
}