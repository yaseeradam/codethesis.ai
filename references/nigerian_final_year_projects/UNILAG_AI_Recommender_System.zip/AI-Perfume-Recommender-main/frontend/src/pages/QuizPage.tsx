import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Spinner from '../components/Spinner'
import './QuizPage.css'

const ACCORDS = [
  { name: 'floral',       emoji: '🌸' },
  { name: 'woody',        emoji: '🪵' },
  { name: 'citrus',       emoji: '🍋' },
  { name: 'fresh',        emoji: '💨' },
  { name: 'oriental',     emoji: '🌙' },
  { name: 'musky',        emoji: '🤍' },
  { name: 'vanilla',      emoji: '🍦' },
  { name: 'gourmand',     emoji: '🍫' },
  { name: 'aquatic',      emoji: '🌊' },
  { name: 'spicy',        emoji: '🌶️' },
  { name: 'aromatic',     emoji: '🌿' },
  { name: 'fruity',       emoji: '🍑' },
  { name: 'powdery',      emoji: '🫧' },
  { name: 'amber',        emoji: '🟠' },
  { name: 'leather',      emoji: '🤎' },
  { name: 'green',        emoji: '🍃' },
]

interface Preferences {
  accords:    string[]
  gender:     string
  price_tier: string
  longevity:  string
  season:     string
}

const STEPS = ['Scents', 'Style', 'Results']

export default function QuizPage() {
  const navigate = useNavigate()
  const [step, setStep]       = useState(1)
  const [loading, setLoading] = useState(false)
  const [error, setError]     = useState('')

  const [prefs, setPrefs] = useState<Preferences>({
    accords:    [],
    gender:     '',
    price_tier: '',
    longevity:  '',
    season:     '',
  })

  const toggleAccord = (accord: string) => {
    setPrefs(prev => ({
      ...prev,
      accords: prev.accords.includes(accord)
        ? prev.accords.filter(a => a !== accord)
        : [...prev.accords, accord]
    }))
  }

  const canProceedStep1 = prefs.accords.length > 0
  const canProceedStep2 = prefs.gender && prefs.price_tier && prefs.longevity && prefs.season

  const handleSubmit = async () => {
    setLoading(true)
    setError('')
    try {
      const session_id = sessionStorage.getItem('session_id') || crypto.randomUUID()
      sessionStorage.setItem('session_id', session_id)

      const res = await fetch('/api/recommend', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ preferences: prefs, session_id, top_n: 10 })
      })

      const data = await res.json()
      if (!data.success) throw new Error(data.message)

      // Save results to sessionStorage and navigate
      sessionStorage.setItem('recommendations', JSON.stringify(data.recommendations))
      navigate('/results')
    } catch (err: any) {
      setError('Something went wrong. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="quiz-container">

      {/* Header */}
      <div className="quiz-header">
        <button className="back-btn" onClick={() => step === 1 ? navigate('/') : setStep(1)}>
          ← Back
        </button>
        <div className="step-indicators">
          {STEPS.map((label, i) => (
            <div key={label} className={`step-indicator ${i + 1 <= step ? 'active' : ''}`}>
              <div className="step-dot">{i + 1}</div>
              <span className="step-label">{label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Step 1 — Scent Families */}
      {step === 1 && (
        <div className="quiz-step">
          <div className="step-heading">
            <h2>What scents do you love?</h2>
            <p>Select all that appeal to you</p>
          </div>

          <div className="accord-grid">
            {ACCORDS.map(acc => (
              <button
                key={acc.name}
                className={`accord-chip ${prefs.accords.includes(acc.name) ? 'selected' : ''}`}
                onClick={() => toggleAccord(acc.name)}
              >
                <span className="accord-emoji">{acc.emoji}</span>
                <span className="accord-name">{acc.name}</span>
              </button>
            ))}
          </div>

          <div className="selected-count">
            {prefs.accords.length > 0
              ? `${prefs.accords.length} selected`
              : 'Select at least one'}
          </div>

          <button
            className="next-btn"
            onClick={() => setStep(2)}
            disabled={!canProceedStep1}
          >
            Next →
          </button>
        </div>
      )}

      {/* Step 2 — Style Preferences */}
      {step === 2 && (
        <div className="quiz-step">
          <div className="step-heading">
            <h2>Tell us your style</h2>
            <p>Help us narrow down your perfect match</p>
          </div>

          {/* Gender */}
          <div className="pref-section">
            <label className="pref-label">Gender</label>
            <div className="option-group">
              {[
                { value: 'female', label: '👩 Feminine' },
                { value: 'male',   label: '👨 Masculine' },
                { value: 'unisex', label: '🧑 Unisex' },
              ].map(opt => (
                <button
                  key={opt.value}
                  className={`option-btn ${prefs.gender === opt.value ? 'selected' : ''}`}
                  onClick={() => setPrefs({ ...prefs, gender: opt.value })}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Budget */}
          <div className="pref-section">
            <label className="pref-label">Budget</label>
            <div className="option-group">
              {[
                { value: 'budget',   label: '💰 Budget' },
                { value: 'moderate', label: '💳 Moderate' },
                { value: 'high',     label: '💎 High End' },
              ].map(opt => (
                <button
                  key={opt.value}
                  className={`option-btn ${prefs.price_tier === opt.value ? 'selected' : ''}`}
                  onClick={() => setPrefs({ ...prefs, price_tier: opt.value })}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Longevity */}
          <div className="pref-section">
            <label className="pref-label">How long should it last?</label>
            <div className="option-group">
              {[
                { value: 'light',    label: '🌬️ Light' },
                { value: 'moderate', label: '⏱️ Moderate' },
                { value: 'strong',   label: '💪 Long Lasting' },
              ].map(opt => (
                <button
                  key={opt.value}
                  className={`option-btn ${prefs.longevity === opt.value ? 'selected' : ''}`}
                  onClick={() => setPrefs({ ...prefs, longevity: opt.value })}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Season */}
          <div className="pref-section">
            <label className="pref-label">Preferred season</label>
            <div className="option-group">
              {[
                { value: 'spring', label: '🌸 Spring' },
                { value: 'summer', label: '☀️ Summer' },
                { value: 'fall',   label: '🍂 Fall' },
                { value: 'winter', label: '❄️ Winter' },
              ].map(opt => (
                <button
                  key={opt.value}
                  className={`option-btn ${prefs.season === opt.value ? 'selected' : ''}`}
                  onClick={() => setPrefs({ ...prefs, season: opt.value })}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {error && <p className="error-msg">{error}</p>}

          <button
            className="next-btn"
            onClick={handleSubmit}
            disabled={!canProceedStep2 || loading}
          >
            {loading ? 'Finding matches...' : 'Find My Fragrances ✨'}
          </button>
        </div>
      )}

      {loading && <Spinner />}

    </div>
  )
}