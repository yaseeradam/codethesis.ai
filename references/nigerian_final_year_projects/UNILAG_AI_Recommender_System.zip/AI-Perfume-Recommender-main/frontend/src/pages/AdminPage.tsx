import { useEffect, useState } from 'react'
import { useNavigate }         from 'react-router-dom'
import { authHeaders, logout } from '../utils/auth'
import './AdminPage.css'

interface Perfume {
  perfume_id:        number
  name:              string
  brand:             string
  country_of_origin: string
  target_gender:     string
  price_tier:        string
  longevity:         string
  season_suitability:string
  rating_value:      string
  rating_count:      number
  launch_year:       number
  accords:           string
}

interface Pagination {
  page:  number
  pages: number
  total: number
}

const EMPTY_FORM = {
  name: '', brand: '', country_of_origin: '', target_gender: '',
  price_tier: '', longevity: '', season_suitability: '',
  launch_year: '', description: '', accords: ''
}

export default function AdminPage() {
  const navigate = useNavigate()

  const [perfumes,   setPerfumes]   = useState<Perfume[]>([])
  const [pagination, setPagination] = useState<Pagination>({ page: 1, pages: 1, total: 0 })
  const [search,     setSearch]     = useState('')
  const [loading,    setLoading]    = useState(false)
  const [showModal,  setShowModal]  = useState(false)
  const [editTarget, setEditTarget] = useState<Perfume | null>(null)
  const [form,       setForm]       = useState(EMPTY_FORM)
  const [message,    setMessage]    = useState('')
  const [showPasswordModal, setShowPasswordModal] = useState(false)
  const [passwordForm, setPasswordForm] = useState({
    current_password:  '',
    new_password:      '',
    confirm_password:  ''
  })
  const [passwordMessage, setPasswordMessage] = useState('')
  const [passwordError,   setPasswordError]   = useState('')

  const fetchPerfumes = async (page = 1, q = search) => {
    setLoading(true)
    try {
      // ✅ Auth header added
      const res  = await fetch(`/api/perfumes?page=${page}&limit=20&search=${q}`, {
        headers: authHeaders()
      })

      // Handle token expiry
      if (res.status === 401) {
        logout()
        navigate('/admin/login')
        return
      }

      const data = await res.json()
      setPerfumes(data.data)
      setPagination(data.pagination)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchPerfumes() }, [])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    fetchPerfumes(1, search)
  }

  const openCreate = () => {
    setEditTarget(null)
    setForm(EMPTY_FORM)
    setShowModal(true)
  }

  const openEdit = (p: Perfume) => {
    setEditTarget(p)
    setForm({
      name:               p.name               || '',
      brand:              p.brand              || '',
      country_of_origin:  p.country_of_origin  || '',
      target_gender:      p.target_gender      || '',
      price_tier:         p.price_tier         || '',
      longevity:          p.longevity          || '',
      season_suitability: p.season_suitability || '',
      launch_year:        p.launch_year?.toString() || '',
      description:        '',
      accords:            p.accords            || ''
    })
    setShowModal(true)
  }

  const handleSave = async () => {
    const url    = editTarget ? `/api/perfumes/${editTarget.perfume_id}` : '/api/perfumes'
    const method = editTarget ? 'PUT' : 'POST'

    const body = {
      ...form,
      launch_year: form.launch_year ? parseInt(form.launch_year) : null,
      accords:     form.accords ? form.accords.split(',').map(a => a.trim()) : []
    }

    // ✅ Auth header added
    const res  = await fetch(url, {
      method,
      headers: authHeaders(),
      body:    JSON.stringify(body)
    })
    const data = await res.json()

    if (data.success) {
      setMessage(editTarget ? 'Perfume updated!' : 'Perfume created!')
      setShowModal(false)
      fetchPerfumes(pagination.page)
    } else {
      setMessage('Error: ' + data.message)
    }
    setTimeout(() => setMessage(''), 3000)
  }

  const handleDelete = async (id: number, name: string) => {
    if (!window.confirm(`Delete "${name}"? This cannot be undone.`)) return

    // ✅ Auth header added
    const res  = await fetch(`/api/perfumes/${id}`, {
      method:  'DELETE',
      headers: authHeaders()
    })
    const data = await res.json()

    if (data.success) {
      setMessage('Perfume deleted.')
      fetchPerfumes(pagination.page)
    }
    setTimeout(() => setMessage(''), 3000)
  }

  const handleChangePassword = async () => {
  setPasswordError('')
  setPasswordMessage('')

  const res  = await fetch('/api/auth/change-password', {
    method:  'PUT',
    headers: authHeaders(),
    body:    JSON.stringify(passwordForm)
  })
  const data = await res.json()

  if (data.success) {
    setPasswordMessage('Password changed successfully!')
    setPasswordForm({ current_password: '', new_password: '', confirm_password: '' })
    setTimeout(() => {
      setShowPasswordModal(false)
      setPasswordMessage('')
    }, 2000)
  } else {
    setPasswordError(data.message)
  }
}

  const handleLogout = () => {
    logout()
    navigate('/admin/login')
  }

  return (
    <div className="admin-container">

      {/* Header */}
      <div className="admin-header">
        <div>
          <h1 className="admin-title">Admin Panel</h1>
          <p className="admin-subtitle">{pagination.total.toLocaleString()} perfumes in database</p>
        </div>
        <div className="admin-header-actions">
          <button className="btn-secondary" onClick={() => navigate('/')}>← Home</button>
          <button className="btn-secondary" onClick={handleLogout}>Logout</button>
          <button className="btn-secondary" onClick={() => setShowPasswordModal(true)}>Change Password</button>
          <button className="btn-primary"   onClick={openCreate}>+ Add Perfume</button>
        </div>
      </div>

      {/* Message */}
      {message && <div className="admin-message">{message}</div>}

      {/* Search */}
      <form className="admin-search" onSubmit={handleSearch}>
        <input
          className="search-input"
          placeholder="Search by name or brand..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        <button className="btn-primary" type="submit">Search</button>
        {search && (
          <button className="btn-secondary" type="button" onClick={() => { setSearch(''); fetchPerfumes(1, '') }}>
            Clear
          </button>
        )}
      </form>

      {/* Table */}
      <div className="admin-table-wrapper">
        {loading ? (
          <div className="admin-loading">Loading...</div>
        ) : (
          <table className="admin-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Brand</th>
                <th>Gender</th>
                <th>Price</th>
                <th>Longevity</th>
                <th>Season</th>
                <th>Rating</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {perfumes.map(p => (
                <tr key={p.perfume_id}>
                  <td className="td-id">#{p.perfume_id}</td>
                  <td className="td-name">{p.name}</td>
                  <td className="td-brand">{p.brand}</td>
                  <td><span className="td-badge">{p.target_gender}</span></td>
                  <td><span className="td-badge">{p.price_tier}</span></td>
                  <td>{p.longevity}</td>
                  <td>{p.season_suitability}</td>
                  <td>{p.rating_value ? parseFloat(p.rating_value).toFixed(1) : '—'}</td>
                  <td>
                    <div className="td-actions">
                      <button className="action-edit"   onClick={() => openEdit(p)}>Edit</button>
                      <button className="action-delete" onClick={() => handleDelete(p.perfume_id, p.name)}>Delete</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Pagination */}
      <div className="admin-pagination">
        <button
          className="btn-secondary"
          disabled={pagination.page <= 1}
          onClick={() => fetchPerfumes(pagination.page - 1)}
        >
          ← Prev
        </button>
        <span className="page-info">Page {pagination.page} of {pagination.pages}</span>
        <button
          className="btn-secondary"
          disabled={pagination.page >= pagination.pages}
          onClick={() => fetchPerfumes(pagination.page + 1)}
        >
          Next →
        </button>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2>{editTarget ? 'Edit Perfume' : 'Add New Perfume'}</h2>
              <button className="modal-close" onClick={() => setShowModal(false)}>✕</button>
            </div>

            <div className="modal-body">
              <div className="form-row">
                <div className="form-group">
                  <label>Name *</label>
                  <input value={form.name} onChange={e => setForm({...form, name: e.target.value})} placeholder="Perfume name" />
                </div>
                <div className="form-group">
                  <label>Brand *</label>
                  <input value={form.brand} onChange={e => setForm({...form, brand: e.target.value})} placeholder="Brand" />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Gender *</label>
                  <select value={form.target_gender} onChange={e => setForm({...form, target_gender: e.target.value})}>
                    <option value="">Select...</option>
                    <option value="female">Female</option>
                    <option value="male">Male</option>
                    <option value="unisex">Unisex</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Price Tier</label>
                  <select value={form.price_tier} onChange={e => setForm({...form, price_tier: e.target.value})}>
                    <option value="">Select...</option>
                    <option value="budget">Budget</option>
                    <option value="moderate">Moderate</option>
                    <option value="high">High End</option>
                  </select>
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Longevity</label>
                  <select value={form.longevity} onChange={e => setForm({...form, longevity: e.target.value})}>
                    <option value="">Select...</option>
                    <option value="light">Light</option>
                    <option value="moderate">Moderate</option>
                    <option value="strong">Strong</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Season</label>
                  <select value={form.season_suitability} onChange={e => setForm({...form, season_suitability: e.target.value})}>
                    <option value="">Select...</option>
                    <option value="spring">Spring</option>
                    <option value="summer">Summer</option>
                    <option value="fall">Fall</option>
                    <option value="winter">Winter</option>
                  </select>
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Country</label>
                  <input value={form.country_of_origin} onChange={e => setForm({...form, country_of_origin: e.target.value})} placeholder="e.g. France" />
                </div>
                <div className="form-group">
                  <label>Launch Year</label>
                  <input type="number" value={form.launch_year} onChange={e => setForm({...form, launch_year: e.target.value})} placeholder="e.g. 2020" />
                </div>
              </div>

              <div className="form-group">
                <label>Accords (comma separated)</label>
                <input value={form.accords} onChange={e => setForm({...form, accords: e.target.value})} placeholder="e.g. floral, woody, citrus" />
              </div>

              <div className="form-group">
                <label>Description</label>
                <textarea value={form.description} onChange={e => setForm({...form, description: e.target.value})} placeholder="Optional description..." rows={3} />
              </div>
            </div>

            <div className="modal-footer">
              <button className="btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
              <button className="btn-primary"   onClick={handleSave}>
                {editTarget ? 'Save Changes' : 'Create Perfume'}
              </button>
            </div>
          </div>
        </div>
      )}

    {/* Change Password Modal */}
    {showPasswordModal && (
    <div className="modal-overlay" onClick={() => setShowPasswordModal(false)}>
        <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
            <h2>🔑 Change Password</h2>
            <button className="modal-close" onClick={() => setShowPasswordModal(false)}>✕</button>
        </div>

        <div className="modal-body">
            <div className="form-group">
            <label>Current Password</label>
            <input
                type="password"
                placeholder="Enter current password"
                value={passwordForm.current_password}
                onChange={e => setPasswordForm({...passwordForm, current_password: e.target.value})}
            />
            </div>
            <div className="form-group">
            <label>New Password</label>
            <input
                type="password"
                placeholder="Enter new password (min 6 characters)"
                value={passwordForm.new_password}
                onChange={e => setPasswordForm({...passwordForm, new_password: e.target.value})}
            />
            </div>
            <div className="form-group">
            <label>Confirm New Password</label>
            <input
                type="password"
                placeholder="Confirm new password"
                value={passwordForm.confirm_password}
                onChange={e => setPasswordForm({...passwordForm, confirm_password: e.target.value})}
            />
            </div>

            {passwordError   && <p className="login-error">{passwordError}</p>}
            {passwordMessage && <p className="admin-message">{passwordMessage}</p>}
        </div>

        <div className="modal-footer">
            <button className="btn-secondary" onClick={() => setShowPasswordModal(false)}>Cancel</button>
            <button className="btn-primary"   onClick={handleChangePassword}>Change Password</button>
        </div>
        </div>
    </div>
    )}

    </div>
  )
}