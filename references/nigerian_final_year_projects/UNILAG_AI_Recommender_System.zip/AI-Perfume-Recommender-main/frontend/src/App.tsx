import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Navbar         from './components/Navbar'
import HomePage       from './pages/HomePage'
import QuizPage       from './pages/QuizPage'
import ResultsPage    from './pages/ResultsPage'
import AdminPage      from './pages/AdminPage'
import LoginPage      from './pages/LoginPage'
import ProtectedRoute from './components/ProtectedRoute'

function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/"            element={<HomePage />}    />
        <Route path="/quiz"        element={<QuizPage />}    />
        <Route path="/results"     element={<ResultsPage />} />
        <Route path="/admin/login" element={<LoginPage />}   />
        <Route path="/admin"       element={
          <ProtectedRoute>
            <AdminPage />
          </ProtectedRoute>
        } />
      </Routes>
    </BrowserRouter>
  )
}

export default App