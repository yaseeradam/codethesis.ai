export const getToken = (): string | null => {
  return sessionStorage.getItem('admin_token');
};

export const isLoggedIn = (): boolean => {
  return !!getToken();
};

export const logout = (): void => {
  sessionStorage.removeItem('admin_token');
};

export const authHeaders = (): Record<string, string> => ({
  'Content-Type':  'application/json',
  'Authorization': `Bearer ${getToken()}`
});