"""
precompute_vectors.py — Builds and stores feature vectors for all perfumes
Run AFTER seed.py:
    python precompute_vectors.py
"""

import mysql.connector
import json
import math
import os
from dotenv import load_dotenv

# ── Config ─────────────────────────────────────────────────────────────────
DB_CONFIG = {
    'host':               os.getenv('AIVEN_DB_HOST'),
    'user':               os.getenv('AIVEN_DB_USER'),
    'password':           os.getenv('AIVEN_DB_PASSWORD'),
    'database':           os.getenv('AIVEN_DB_NAME'),
    'port':                int(os.getenv('AIVEN_DB_PORT', '3306')),
    'connection_timeout':  300
}

# These must match recommender.py exactly
GENDERS     = ['male', 'female', 'unisex']
PRICE_TIERS = ['budget', 'moderate', 'high']
LONGEVITY   = ['light', 'moderate', 'strong']
SEASONS     = ['spring', 'summer', 'fall', 'winter']

# ── Connect ────────────────────────────────────────────────────────────────
conn   = mysql.connector.connect(**DB_CONFIG)
cursor = conn.cursor(dictionary=True)

# ── Fetch all unique accords (to build consistent vector index) ────────────
cursor.execute("SELECT accord_id, accord_name FROM Accord ORDER BY accord_id")
all_accords = cursor.fetchall()
ACCORD_INDEX = {row['accord_name']: i for i, row in enumerate(all_accords)}
print(f"Accord dimensions: {len(ACCORD_INDEX)}")

# ── Build vector for one perfume ───────────────────────────────────────────
def build_vector(perfume, perfume_accords):
    vector = []

    # Accords (multi-hot) — one slot per unique accord in DB
    for accord_name in ACCORD_INDEX:
        vector.append(1.0 if accord_name in perfume_accords else 0.0)

    # Gender (one-hot)
    for g in GENDERS:
        vector.append(1.0 if perfume['target_gender'] == g else 0.0)

    # Price tier (one-hot)
    for p in PRICE_TIERS:
        vector.append(1.0 if perfume['price_tier'] == p else 0.0)

    # Longevity (one-hot)
    for l in LONGEVITY:
        vector.append(1.0 if perfume['longevity'] == l else 0.0)

    # Season (one-hot — perfume has one primary season)
    for s in SEASONS:
        vector.append(1.0 if perfume['season_suitability'] == s else 0.0)

    return vector

# ── Fetch all perfumes with their accords ──────────────────────────────────
cursor.execute("SELECT COUNT(*) as total FROM Perfume WHERE feature_vector IS NULL")
total = cursor.fetchone()['total']
print(f"Perfumes to process: {total}\n")

cursor.execute("""
    SELECT 
        p.perfume_id,
        p.target_gender,
        p.price_tier,
        p.longevity,
        p.season_suitability,
        GROUP_CONCAT(a.accord_name) AS accord_names
    FROM Perfume p
    LEFT JOIN Perfume_Accord pa ON p.perfume_id = pa.perfume_id
    LEFT JOIN Accord a ON pa.accord_id = a.accord_id
    WHERE p.feature_vector IS NULL
    GROUP BY p.perfume_id
""")
perfumes = cursor.fetchall()

# ── Process and update ─────────────────────────────────────────────────────
update_cursor = conn.cursor()
processed = 0

for perfume in perfumes:
    accords = perfume['accord_names'].split(',') if perfume['accord_names'] else []
    vector  = build_vector(perfume, accords)

    update_cursor.execute(
        "UPDATE Perfume SET feature_vector = %s WHERE perfume_id = %s",
        (json.dumps(vector), perfume['perfume_id'])
    )
    processed += 1

    if processed % 1000 == 0:
        conn.commit()
        print(f"  Processed {processed}/{total}...")

conn.commit()
update_cursor.close()

# ── Verify ─────────────────────────────────────────────────────────────────
cursor.execute("SELECT COUNT(*) as done FROM Perfume WHERE feature_vector IS NOT NULL")
done = cursor.fetchone()['done']
print(f"\nDone! {done} perfumes now have feature vectors.")
print(f"Vector size: {len(vector)} dimensions")
print(f"  ({len(ACCORD_INDEX)} accords + {len(GENDERS)} gender + {len(PRICE_TIERS)} price + {len(LONGEVITY)} longevity + {len(SEASONS)} season)")

cursor.close()
conn.close()
