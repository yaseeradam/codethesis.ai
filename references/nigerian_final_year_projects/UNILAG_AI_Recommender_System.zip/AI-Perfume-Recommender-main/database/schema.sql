-- ============================================================
-- Perfume Recommender Database Schema
-- Based on Fragrantica dataset (fra_cleaned.csv)
-- ============================================================

CREATE DATABASE IF NOT EXISTS perfume_db;
USE perfume_db;

-- ── Accords ──────────────────────────────────────────────────
-- Stores unique scent families (e.g. rose, woody, citrus)
-- Dataset has 84 unique accords across 5 accord columns
CREATE TABLE Accord (
  accord_id   INT AUTO_INCREMENT PRIMARY KEY,
  accord_name VARCHAR(100) NOT NULL UNIQUE
);

-- ── Notes ────────────────────────────────────────────────────
-- Stores individual fragrance notes with their type
-- Dataset has Top, Middle, Base note columns (comma-separated)
CREATE TABLE Note (
  note_id   INT AUTO_INCREMENT PRIMARY KEY,
  note_name VARCHAR(150) NOT NULL,
  note_type ENUM('top', 'middle', 'base') NOT NULL,
  UNIQUE KEY unique_note (note_name, note_type)
);

-- ── Perfume ───────────────────────────────────────────────────
-- Core perfume table
-- Dropped: bottle_size_ml, projection, price (not in dataset)
-- Auto-generated: price_tier, longevity, season_suitability
CREATE TABLE Perfume (
  perfume_id        INT AUTO_INCREMENT PRIMARY KEY,
  name              VARCHAR(255) NOT NULL,
  brand             VARCHAR(255) NOT NULL,
  country_of_origin VARCHAR(100),
  target_gender     ENUM('male', 'female', 'unisex') NOT NULL,
  price_tier        ENUM('budget', 'moderate', 'high'),
  longevity         ENUM('light', 'moderate', 'strong'),
  season_suitability SET('spring', 'summer', 'fall', 'winter'),
  rating_value      DECIMAL(3,2),
  rating_count      INT,
  launch_year       YEAR,
  image_url         VARCHAR(500),
  description       TEXT,
  feature_vector    JSON,
  UNIQUE KEY unique_perfume (name, brand)
);

-- ── Perfume ↔ Accord (many-to-many) ──────────────────────────
CREATE TABLE Perfume_Accord (
  perfume_id INT NOT NULL,
  accord_id  INT NOT NULL,
  PRIMARY KEY (perfume_id, accord_id),
  FOREIGN KEY (perfume_id) REFERENCES Perfume(perfume_id) ON DELETE CASCADE,
  FOREIGN KEY (accord_id)  REFERENCES Accord(accord_id)  ON DELETE CASCADE
);

-- ── Perfume ↔ Note (many-to-many) ────────────────────────────
CREATE TABLE Perfume_Note (
  perfume_id INT NOT NULL,
  note_id    INT NOT NULL,
  PRIMARY KEY (perfume_id, note_id),
  FOREIGN KEY (perfume_id) REFERENCES Perfume(perfume_id) ON DELETE CASCADE,
  FOREIGN KEY (note_id)    REFERENCES Note(note_id)       ON DELETE CASCADE
);

-- ── User Preferences ─────────────────────────────────────────
-- Stores each quiz submission (session-based, no login needed)
CREATE TABLE UserPreference (
  preference_id      INT AUTO_INCREMENT PRIMARY KEY,
  session_id         VARCHAR(255) NOT NULL,
  preferred_accords  JSON,
  preferred_gender   ENUM('male', 'female', 'unisex'),
  preferred_price_tier ENUM('budget', 'moderate', 'high'),
  preferred_season   ENUM('spring', 'summer', 'fall', 'winter'),
  preferred_longevity ENUM('light', 'moderate', 'strong'),
  created_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- might reconsider the user choosing season and longevity

-- ── Recommendations ───────────────────────────────────────────
-- Logs every recommendation result for analytics
CREATE TABLE Recommendation (
  recommendation_id INT AUTO_INCREMENT PRIMARY KEY,
  session_id        VARCHAR(255) NOT NULL,
  perfume_id        INT,
  similarity_score  FLOAT,
  rank_position     INT,
  recommended_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (perfume_id) REFERENCES Perfume(perfume_id) ON DELETE SET NULL
);


CREATE TABLE Admin (
  admin_id   INT AUTO_INCREMENT PRIMARY KEY,
  username   VARCHAR(100) NOT NULL UNIQUE,
  password   VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- CREATE TABLE SchemaVersion (
--   version    INT PRIMARY KEY,
--   accord_count INT NOT NULL,
--   updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
-- );