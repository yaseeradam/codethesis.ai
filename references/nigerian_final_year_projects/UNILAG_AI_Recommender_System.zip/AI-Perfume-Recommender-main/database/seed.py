"""
seed.py — Clean and seed the perfume_db database
Run from the /database folder:
    pip install pandas mysql-connector-python
    python seed.py
"""

import pandas as pd
import mysql.connector
import math

# ── Config ─────────────────────────────────────────────────────────────────
DB_CONFIG = {
    'host':     'localhost',
    'user':     'perfume_user',
    'password': 'perfume123',
    'database': 'perfume_db'
}

CSV_PATH = 'fra_cleaned.csv'

# ── Connect ────────────────────────────────────────────────────────────────
print("Connecting to database...")
conn   = mysql.connector.connect(**DB_CONFIG)
cursor = conn.cursor()
print("Connected.\n")

# ── Load & Clean CSV ───────────────────────────────────────────────────────
print("Loading CSV...")
df = pd.read_csv(CSV_PATH, sep=';', encoding='latin1', on_bad_lines='skip')
print(f"Loaded {len(df)} raw rows\n")

# 1. Drop columns we don't need
df = df.drop(columns=['url', 'Perfumer1', 'Perfumer2'])

# 2. Remove duplicates (same perfume name + brand)
df = df.drop_duplicates(subset=['Perfume', 'Brand'])
print(f"After deduplication: {len(df)} rows")

# 3. Drop rows missing essential fields
df = df.dropna(subset=['Perfume', 'Brand', 'Gender', 'mainaccord1'])
print(f"After dropping missing essentials: {len(df)} rows\n")

# ── Helper Functions ───────────────────────────────────────────────────────

def clean_gender(val):
    val = str(val).lower().strip()
    if 'women' in val or 'female' in val:
        return 'female'
    elif 'men' in val or 'male' in val:
        return 'male'
    return 'unisex'

def clean_rating(val):
    """Convert '3,45' → 3.45"""
    try:
        return round(float(str(val).replace(',', '.')), 2)
    except:
        return None

def get_price_tier(rating_count):
    """
    Estimate price tier from popularity.
    High rating count = well-known brand = usually higher priced.
    """
    try:
        count = int(str(rating_count).replace(',', ''))
        if count >= 5000:
            return 'high'
        elif count >= 500:
            return 'moderate'
        return 'budget'
    except:
        return 'moderate'

def get_longevity(base_notes):
    """
    Estimate longevity from base notes.
    Heavy base notes = longer lasting fragrance.
    """
    heavy_bases = [
        'musk', 'amber', 'oud', 'sandalwood', 'vanilla',
        'patchouli', 'cedar', 'vetiver', 'leather', 'resin',
        'benzyl', 'labdanum', 'oakmoss', 'incense', 'tonka'
    ]
    base = str(base_notes).lower()
    matches = sum(1 for note in heavy_bases if note in base)
    if matches >= 3:
        return 'strong'
    elif matches >= 1:
        return 'moderate'
    return 'light'

def get_season(accords_str):
    """
    Estimate best season from combined accord string.
    """
    accords = accords_str.lower()
    if any(x in accords for x in ['fresh', 'citrus', 'aquatic', 'ozonic', 'marine', 'green']):
        return 'summer'
    elif any(x in accords for x in ['woody', 'oud', 'amber', 'warm spicy', 'tobacco', 'leather', 'smoky']):
        return 'winter'
    elif any(x in accords for x in ['floral', 'fruity', 'tropical', 'white floral', 'yellow floral']):
        return 'spring'
    return 'fall'

def get_accords(row):
    """Collect all non-null accords from 5 accord columns."""
    accords = []
    for col in ['mainaccord1', 'mainaccord2', 'mainaccord3', 'mainaccord4', 'mainaccord5']:
        val = str(row.get(col, '')).strip().lower()
        if val and val != 'nan':
            accords.append(val)
    return list(dict.fromkeys(accords))  # deduplicate, preserve order

def get_year(val):
    try:
        year = int(float(str(val)))
        if 1700 <= year <= 2026:
            return year
        return None
    except:
        return None

def clean_name(val):
    """Convert url-style name to readable: 'my-perfume-name' → 'My Perfume Name'"""
    return str(val).replace('-', ' ').strip().title()

# ── Step 1: Collect and Insert All Unique Accords ─────────────────────────
print("── Step 1: Inserting accords...")
all_accords = set()
for _, row in df.iterrows():
    all_accords.update(get_accords(row))

accord_map = {}  # accord_name → accord_id
for accord in sorted(all_accords):
    if accord:
        cursor.execute(
            "INSERT IGNORE INTO Accord (accord_name) VALUES (%s)", (accord,)
        )
        cursor.execute(
            "SELECT accord_id FROM Accord WHERE accord_name = %s", (accord,)
        )
        result = cursor.fetchone()
        if result:
            accord_map[accord] = result[0]

conn.commit()
print(f"   Inserted {len(accord_map)} unique accords\n")

# ── Step 2: Insert Notes ───────────────────────────────────────────────────
print("── Step 2: Inserting notes...")
note_map = {}  # (note_name, note_type) → note_id

def insert_notes_from_col(notes_str, note_type):
    if not notes_str or str(notes_str).strip().lower() in ['nan', 'unknown', '']:
        return []
    notes = [n.strip().lower() for n in str(notes_str).split(',') if n.strip()]
    ids = []
    for note in notes:
        if not note or note == 'nan':
            continue
        key = (note, note_type)
        if key not in note_map:
            cursor.execute(
                "INSERT IGNORE INTO Note (note_name, note_type) VALUES (%s, %s)",
                (note, note_type)
            )
            cursor.execute(
                "SELECT note_id FROM Note WHERE note_name = %s AND note_type = %s",
                (note, note_type)
            )
            result = cursor.fetchone()
            if result:
                note_map[key] = result[0]
        if key in note_map:
            ids.append(note_map[key])
    return ids

# Pre-scan all notes
for _, row in df.iterrows():
    insert_notes_from_col(row.get('Top'),    'top')
    insert_notes_from_col(row.get('Middle'), 'middle')
    insert_notes_from_col(row.get('Base'),   'base')

conn.commit()
print(f"   Inserted {len(note_map)} unique notes\n")

# ── Step 3: Insert Perfumes ────────────────────────────────────────────────
print("── Step 3: Inserting perfumes...")
inserted = 0
skipped  = 0

for _, row in df.iterrows():
    raw_name  = str(row.get('Perfume', '')).strip()
    raw_brand = str(row.get('Brand', '')).strip()

    if not raw_name or not raw_brand or raw_name == 'nan' or raw_brand == 'nan':
        skipped += 1
        continue

    name    = clean_name(raw_name)
    brand   = clean_name(raw_brand)
    country = str(row.get('Country', '')).strip() or None
    gender  = clean_gender(row.get('Gender'))
    rating  = clean_rating(row.get('Rating Value'))
    r_count = int(str(row.get('Rating Count', 0)).replace(',', '') or 0)

    accords       = get_accords(row)
    accords_str   = ' '.join(accords)
    price_tier    = get_price_tier(r_count)
    longevity     = get_longevity(row.get('Base', ''))
    season        = get_season(accords_str)
    launch_year   = get_year(row.get('Year'))

    try:
        cursor.execute("""
            INSERT IGNORE INTO Perfume
            (name, brand, country_of_origin, target_gender, price_tier,
             longevity, season_suitability, rating_value, rating_count, launch_year)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (
            name, brand, country, gender, price_tier,
            longevity, season, rating, r_count, launch_year
        ))

        perfume_id = cursor.lastrowid
        if perfume_id == 0:   # INSERT IGNORE skipped a duplicate
            skipped += 1
            continue

        # Link accords
        for accord in accords:
            if accord in accord_map:
                cursor.execute(
                    "INSERT IGNORE INTO Perfume_Accord (perfume_id, accord_id) VALUES (%s, %s)",
                    (perfume_id, accord_map[accord])
                )

        # Link notes
        top_ids    = insert_notes_from_col(row.get('Top'),    'top')
        middle_ids = insert_notes_from_col(row.get('Middle'), 'middle')
        base_ids   = insert_notes_from_col(row.get('Base'),   'base')

        for note_id in top_ids + middle_ids + base_ids:
            cursor.execute(
                "INSERT IGNORE INTO Perfume_Note (perfume_id, note_id) VALUES (%s, %s)",
                (perfume_id, note_id)
            )

        inserted += 1
        if inserted % 1000 == 0:
            conn.commit()
            print(f"   {inserted} perfumes inserted...")

    except Exception as e:
        skipped += 1
        continue

conn.commit()
print(f"\n   Done! Inserted: {inserted} | Skipped/Duplicates: {skipped}\n")

# ── Step 4: Summary ────────────────────────────────────────────────────────
print("── Final Summary:")
for table in ['Perfume', 'Accord', 'Note', 'Perfume_Accord', 'Perfume_Note']:
    cursor.execute(f"SELECT COUNT(*) FROM {table}")
    count = cursor.fetchone()[0]
    print(f"   {table}: {count} records")

cursor.close()
conn.close()
print("\nDatabase seeded successfully!")
