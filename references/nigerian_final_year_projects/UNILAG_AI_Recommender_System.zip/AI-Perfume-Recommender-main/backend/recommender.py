import json
import sys
import math

# These must match precompute_vectors.py exactly
GENDERS     = ['male', 'female', 'unisex']
PRICE_TIERS = ['budget', 'moderate', 'high']
LONGEVITY   = ['light', 'moderate', 'strong']
SEASONS     = ['spring', 'summer', 'fall', 'winter']

def build_user_vector(preferences: dict, accord_index: dict) -> list:
    vector = []

    # Accords (multi-hot) — same order as accord_index
    selected_accords = preferences.get('accords', [])
    for accord_name in accord_index:
        vector.append(1.0 if accord_name in selected_accords else 0.0)

    # Gender (one-hot)
    for g in GENDERS:
        vector.append(1.0 if g == preferences.get('gender') else 0.0)

    # Price tier (one-hot)
    for p in PRICE_TIERS:
        vector.append(1.0 if p == preferences.get('price_tier') else 0.0)

    # Longevity (one-hot)
    for l in LONGEVITY:
        vector.append(1.0 if l == preferences.get('longevity') else 0.0)

    # Season (one-hot)
    for s in SEASONS:
        vector.append(1.0 if s == preferences.get('season') else 0.0)

    return vector


def cosine_similarity(vec_a: list, vec_b: list) -> float:
    dot_product = sum(a * b for a, b in zip(vec_a, vec_b))
    magnitude_a = math.sqrt(sum(a ** 2 for a in vec_a))
    magnitude_b = math.sqrt(sum(b ** 2 for b in vec_b))
    if magnitude_a == 0 or magnitude_b == 0:
        return 0.0
    return dot_product / (magnitude_a * magnitude_b)


def generate_explanation(preferences: dict, perfume: dict) -> str:
    reasons = []

    user_accords    = preferences.get('accords', [])
    perfume_accords = perfume.get('accords', [])
    matched_accords = [a for a in user_accords if a in perfume_accords]
    if matched_accords:
        reasons.append(f"Matches your {', '.join(matched_accords)} scent preference")

    if preferences.get('longevity') == perfume.get('longevity'):
        reasons.append(f"{perfume['longevity']} longevity as preferred")

    if preferences.get('price_tier') == perfume.get('price_tier'):
        reasons.append(f"fits your {perfume['price_tier']} budget")

    if preferences.get('season') == perfume.get('season_suitability'):
        reasons.append(f"great for {perfume['season_suitability']}")

    return '. '.join(reasons) + '.' if reasons else 'Good overall match for your preferences.'


def recommend(preferences: dict, perfumes: list, accord_index: dict, top_n: int = 10) -> list:
    user_vector = build_user_vector(preferences, accord_index)
    results = []

    for perfume in perfumes:
        perf_vector = perfume.get('feature_vector')
        if not perf_vector:
            continue

        score = cosine_similarity(user_vector, perf_vector)
        results.append({
            'perfume_id':       perfume['perfume_id'],
            'name':             perfume['name'],
            'brand':            perfume['brand'],
            'price_tier':       perfume['price_tier'],
            'longevity':        perfume['longevity'],
            'season':           perfume['season_suitability'],
            'gender':           perfume['target_gender'],
            'rating_value':     perfume.get('rating_value'),
            'image_url':        perfume.get('image_url', ''),
            'similarity_score': round(score * 100, 2),
            'explanation':      generate_explanation(preferences, perfume)
        })

    results.sort(key=lambda x: x['similarity_score'], reverse=True)
    return results[:top_n]


# ── Entry point (called by Node.js via child_process) ─────────────────────
if __name__ == '__main__':
    input_data  = json.loads(sys.stdin.read())
    preferences = input_data['preferences']
    perfumes    = input_data['perfumes']
    accord_index = input_data['accord_index']
    top_n       = input_data.get('top_n', 10)

    recommendations = recommend(preferences, perfumes, accord_index, top_n)
    print(json.dumps(recommendations))