import pool from './connection'
import bcrypt from 'bcryptjs'

export const seedAdminIfNotExists = async () => {
    try {
        const username = process.env.ADMIN_USERNAME || 'admin'
        const password = process.env.ADMIN_PASSWORD || 'admin123'

        const [rows]: any = await pool.query(
            'SELECT admin_id FROM Admin WHERE username = ?', [username]
        )

        if (rows.length == 0){
            const hashed = await bcrypt.hash(password, 10)
            await pool.query(
                'INSERT INTO Admin (username, password) VALUES (?, ?)', [username, hashed]
            )
            console.log('Default admin account created')
        }
    }
    catch (err: any) {
        console.error('Admin seed failed:', err.message)
    }
}