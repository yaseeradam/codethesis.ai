import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

const pool = mysql.createPool({
  host:               process.env.DB_HOST     || 'localhost',
  user:               process.env.DB_USER     || 'perfume_user',
  password:           process.env.DB_PASSWORD || 'perfume123',
  database:           process.env.DB_NAME     || 'perfume_db',
  port:               parseInt(process.env.DB_PORT || '3306'),
  waitForConnections: true,
  connectionLimit:    10,
  ssl: process.env.DB_HOST?.includes('railway') ? { rejectUnauthorized: false } : undefined
});

pool.getConnection()
  .then(conn => {
    console.log('✅ Database connected successfully');
    conn.release();
  })
  .catch(err => {
    console.error('❌ Database connection failed:', err.message);
  });

export default pool;