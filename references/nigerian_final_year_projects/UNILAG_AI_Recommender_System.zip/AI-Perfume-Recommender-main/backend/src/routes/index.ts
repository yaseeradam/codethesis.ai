import { Router }             from 'express';
import { getRecommendations } from '../controllers/recommendController';
import {
  getAllPerfumes,
  getPerfumeById,
  createPerfume,
  updatePerfume,
  deletePerfume,
} from '../controllers/adminController';
import { login, verifyToken, changePassword } from '../controllers/authController';
import { requireAuth }        from '../middleware/auth';

const router = Router();

// ── Public routes ─────────────────────────────────────────────
router.post('/recommend',          getRecommendations);
router.post('/auth/login',         login);

// ── Protected routes ──────────────────────────────────────────
router.get('/auth/verify',         requireAuth, verifyToken);
router.put('/auth/change-password',requireAuth, changePassword);
router.get('/perfumes',            requireAuth, getAllPerfumes);
router.get('/perfumes/:id',        requireAuth, getPerfumeById);
router.post('/perfumes',           requireAuth, createPerfume);
router.put('/perfumes/:id',        requireAuth, updatePerfume);
router.delete('/perfumes/:id',     requireAuth, deletePerfume);

export default router;