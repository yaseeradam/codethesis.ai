import { Request, Response } from 'express';
import { spawn }             from 'child_process';
import path                  from 'path';
import pool                  from '../db/connection';

export const getRecommendations = async (req: Request, res: Response) => {
  try {
    const { preferences, session_id, top_n = 10 } = req.body;

    if (!preferences || !session_id) {
      res.status(400).json({ success: false, message: 'preferences and session_id are required' });
      return;
    }

    // ── 1. Fetch accord index ─────────────────────────────────────
    const [accordRows]: any = await pool.query(
      'SELECT accord_name FROM Accord ORDER BY accord_id'
    );
    const accord_index: Record<string, number> = {};
    accordRows.forEach((row: any, i: number) => {
      accord_index[row.accord_name] = i;
    });

    // ── 2. Fetch only perfume IDs and their feature vectors ───────
    const [perfumes]: any = await pool.query(`
      SELECT
        p.perfume_id,
        p.name,
        p.brand,
        p.target_gender,
        p.price_tier,
        p.longevity,
        p.season_suitability,
        p.rating_value,
        p.image_url,
        p.feature_vector,
        GROUP_CONCAT(a.accord_name ORDER BY a.accord_name) AS accord_names
      FROM Perfume p
      LEFT JOIN Perfume_Accord pa ON p.perfume_id = pa.perfume_id
      LEFT JOIN Accord a          ON pa.accord_id  = a.accord_id
      WHERE p.feature_vector IS NOT NULL
      GROUP BY p.perfume_id
    `);

  const formattedPerfumes = perfumes.map((p: any) => {
    let featureVector = [];

    try {
      featureVector =
        typeof p.feature_vector === 'string'
          ? JSON.parse(p.feature_vector)
          : p.feature_vector || [];
    } catch (err) {
      console.error(
        `Invalid feature vector for perfume ${p.perfume_id}:`,
        p.feature_vector
      );

      featureVector = [];
    }

    return {
      perfume_id: p.perfume_id,
      name: p.name,
      brand: p.brand,
      target_gender: p.target_gender,
      price_tier: p.price_tier,
      longevity: p.longevity,
      season_suitability: p.season_suitability,
      rating_value: p.rating_value,
      image_url: p.image_url || '',
      accords: p.accord_names ? p.accord_names.split(',') : [],
      feature_vector: featureVector,
    };
  });

    // ── 3. Call Python ────────────────────────────────────────────
    const pythonInput = JSON.stringify({
      preferences,
      perfumes: formattedPerfumes,
      accord_index,
      top_n
    });

    const recommendations = await new Promise<any[]>((resolve, reject) => {
      const scriptPath = path.resolve('recommender.py');
      const python     = spawn('python', [scriptPath]);
      let output = '';
      let error  = '';

      python.stdin.write(pythonInput);
      python.stdin.end();

      python.stdout.on('data', (data) => { output += data.toString(); });
      python.stderr.on('data', (data) => { error  += data.toString(); });

      python.on('close', (code) => {
        if (code !== 0) {
          return reject(new Error(error || 'Python process failed'));   
        } 
        try {
          // Extract only the JSON array, ignoring any injected text around it
          const start   = output.indexOf('[');
          const end     = output.lastIndexOf(']');
          if (start === -1 || end === -1) {
            return reject(new Error(`No JSON array found. Output: ${output.substring(0, 200)}`));
          }
          const jsonStr = output.substring(start, end + 1);
          resolve(JSON.parse(jsonStr));        
        } 
        catch (e: any) {
          reject(
            new Error(
              `Invalid JSON from Python: ${e.message}\nOutput: ${output.substring(0, 200)}`
            )
          );
        }
      });
    });

    // ── 4. Save preferences ───────────────────────────────────────
    await pool.query(`
      INSERT INTO UserPreference
        (session_id, preferred_accords, preferred_gender,
         preferred_price_tier, preferred_season, preferred_longevity)
      VALUES (?, ?, ?, ?, ?, ?)
    `, [
      session_id,
      JSON.stringify(preferences.accords || []),
      preferences.gender     || null,
      preferences.price_tier || null,
      preferences.season     || null,
      preferences.longevity  || null,
    ]);

    // ── 5. Log recommendations ────────────────────────────────────
    if (recommendations.length > 0) {
      const logValues = recommendations.map((rec: any, index: number) =>
        [session_id, rec.perfume_id, rec.similarity_score, index + 1]
      );
      await pool.query(
        `INSERT INTO Recommendation (session_id, perfume_id, similarity_score, rank_position) VALUES ?`,
        [logValues]
      );
    }

    res.json({ success: true, count: recommendations.length, recommendations });

  } catch (error: any) {
    console.error('Recommendation error:', error.message);
    res.status(500).json({ success: false, message: 'Recommendation failed', error: error.message });
  }
};