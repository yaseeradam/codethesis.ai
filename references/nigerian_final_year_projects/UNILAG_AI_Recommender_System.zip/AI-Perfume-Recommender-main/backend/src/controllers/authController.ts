import { Request, Response } from 'express';
import jwt                   from 'jsonwebtoken';
import bcrypt                from 'bcryptjs';
import pool                  from '../db/connection';

const JWT_SECRET = process.env.JWT_SECRET || 'fallback_secret';

// ── Login ─────────────────────────────────────────────────────
export const login = async (req: Request, res: Response) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      res.status(400).json({ success: false, message: 'Username and password required' });
      return;
    }

    // Find admin in database
    const [rows]: any = await pool.query(
      'SELECT * FROM Admin WHERE username = ?', [username]
    );

    if (rows.length === 0) {
      res.status(401).json({ success: false, message: 'Invalid credentials' });
      return;
    }

    const admin = rows[0];

    // Compare password with hash
    const isMatch = await bcrypt.compare(password, admin.password);
    if (!isMatch) {
      res.status(401).json({ success: false, message: 'Invalid credentials' });
      return;
    }

    // Generate JWT
    const token = jwt.sign(
      { admin_id: admin.admin_id, username: admin.username, role: 'admin' },
      JWT_SECRET,
      { expiresIn: '8h' }
    );

    res.json({ success: true, token, message: 'Login successful' });

  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ── Verify Token ──────────────────────────────────────────────
export const verifyToken = (req: Request, res: Response) => {
  res.json({ success: true, message: 'Token is valid' });
};

// ── Change Password ───────────────────────────────────────────
export const changePassword = async (req: Request, res: Response) => {
  try {
    const { current_password, new_password, confirm_password } = req.body;
    const admin_id = (req as any).admin.admin_id;

    // Validate fields
    if (!current_password || !new_password || !confirm_password) {
      res.status(400).json({ success: false, message: 'All fields are required' });
      return;
    }

    if (new_password !== confirm_password) {
      res.status(400).json({ success: false, message: 'New passwords do not match' });
      return;
    }

    if (new_password.length < 6) {
      res.status(400).json({ success: false, message: 'Password must be at least 6 characters' });
      return;
    }

    // Get current admin
    const [rows]: any = await pool.query(
      'SELECT * FROM Admin WHERE admin_id = ?', [admin_id]
    );

    if (rows.length === 0) {
      res.status(404).json({ success: false, message: 'Admin not found' });
      return;
    }

    // Verify current password
    const isMatch = await bcrypt.compare(current_password, rows[0].password);
    if (!isMatch) {
      res.status(401).json({ success: false, message: 'Current password is incorrect' });
      return;
    }

    // Hash and save new password
    const hashed = await bcrypt.hash(new_password, 10);
    await pool.query(
      'UPDATE Admin SET password = ? WHERE admin_id = ?',
      [hashed, admin_id]
    );

    res.json({ success: true, message: 'Password changed successfully' });

  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
};