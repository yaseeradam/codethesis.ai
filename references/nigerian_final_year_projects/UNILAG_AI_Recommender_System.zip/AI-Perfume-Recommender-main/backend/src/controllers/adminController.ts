import { Request, Response } from 'express';
import pool from '../db/connection';
import { buildFeatureVector, rebuildAllVectors } from '../utils/buildVector';

// ── GET all perfumes (paginated) ──────────────────────────────
export const getAllPerfumes = async (req: Request, res: Response) => {
  try {
    const page   = parseInt(req.query.page   as string) || 1;
    const limit  = parseInt(req.query.limit  as string) || 20;
    const search = (req.query.search as string) || '';
    const offset = (page - 1) * limit;

    let perfumeQuery = `
      SELECT
        p.perfume_id,
        p.name,
        p.brand,
        p.country_of_origin,
        p.target_gender,
        p.price_tier,
        p.longevity,
        p.season_suitability,
        p.rating_value,
        p.rating_count,
        p.launch_year,
        GROUP_CONCAT(DISTINCT a.accord_name ORDER BY a.accord_name) AS accords
      FROM Perfume p
      LEFT JOIN Perfume_Accord pa ON p.perfume_id = pa.perfume_id
      LEFT JOIN Accord a          ON pa.accord_id  = a.accord_id
    `;

    let countQuery  = `SELECT COUNT(*) as total FROM Perfume`;
    const params: any[] = [];
    const countParams: any[] = [];

    if (search) {
      perfumeQuery += ` WHERE p.name LIKE ? OR p.brand LIKE ?`;
      countQuery   += ` WHERE name LIKE ? OR brand LIKE ?`;
      params.push(`%${search}%`, `%${search}%`);
      countParams.push(`%${search}%`, `%${search}%`);
    }

    perfumeQuery += ` GROUP BY p.perfume_id ORDER BY p.rating_count DESC LIMIT ? OFFSET ?`;
    params.push(limit, offset);

    const [perfumes]: any  = await pool.query(perfumeQuery, params);
    const [countRows]: any = await pool.query(countQuery, countParams);
    const total            = countRows[0].total;

    res.json({
      success: true,
      data: perfumes,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error: any) {
    console.error('getAllPerfumes error:', error.message);
    res.status(500).json({ success: false, message: error.message });
  }
};

// ── GET single perfume ────────────────────────────────────────
export const getPerfumeById = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    const [[perfume]]: any = await pool.query(`
      SELECT
        p.*,
        GROUP_CONCAT(DISTINCT a.accord_name ORDER BY a.accord_name) AS accords
      FROM Perfume p
      LEFT JOIN Perfume_Accord pa ON p.perfume_id = pa.perfume_id
      LEFT JOIN Accord a          ON pa.accord_id  = a.accord_id
      WHERE p.perfume_id = ?
      GROUP BY p.perfume_id
    `, [id]);

    if (!perfume) {
      res.status(404).json({ success: false, message: 'Perfume not found' });
      return;
    }

    res.json({ success: true, data: perfume });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ── CREATE perfume ────────────────────────────────────────────
export const createPerfume = async (req: Request, res: Response) => {
  try {
    const {
      name, brand, country_of_origin, target_gender,
      price_tier, longevity, season_suitability,
      launch_year, description, accords
    } = req.body;

    if (!name || !brand || !target_gender) {
      res.status(400).json({ success: false, message: 'name, brand and target_gender are required' });
      return;
    }

    const [result]: any = await pool.query(`
      INSERT INTO Perfume
        (name, brand, country_of_origin, target_gender, price_tier,
         longevity, season_suitability, launch_year, description)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      name, brand, country_of_origin || null, target_gender,
      price_tier || null, longevity || null,
      season_suitability || null, launch_year || null,
      description || null
    ]);

    const perfumeId = result.insertId;
    let newAccordAdded = false;

    // Link accords if provided
    if (accords && accords.length > 0) {
      for (const accordName of accords) {
        const [existing]: any = await pool.query(
          'SELECT accord_id FROM Accord WHERE accord_name = ?', [accordName]
        );
        if (existing.length === 0) {
          await pool.query('INSERT INTO Accord (accord_name) VALUES (?)', [accordName]);
          newAccordAdded = true;
        }
        const [[accord]]: any = await pool.query(
          'SELECT accord_id FROM Accord WHERE accord_name = ?', [accordName]
        );
        if (accord) {
          await pool.query(
            'INSERT IGNORE INTO Perfume_Accord (perfume_id, accord_id) VALUES (?, ?)',
            [perfumeId, accord.accord_id]
          );
        }
      }
    }

    // ── NEW: build and save the feature vector ──────────────
    if (newAccordAdded) {
      // A brand new accord changes the dimension count for EVERY perfume 
      // rebuild all vectors so they stay aligned 
      await rebuildAllVectors();
    } else {
      const vector = await buildFeatureVector(perfumeId);
      await pool.query(
        'UPDATE Perfume SET feature_vector = ? WHERE perfume_id = ?',
        [JSON.stringify(vector), perfumeId]
      );
    }

    // status code 201 means a resource has been created while 500 means internal server error
    res.status(201).json({ success: true, message: 'Perfume created', perfume_id: perfumeId });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ── UPDATE perfume ────────────────────────────────────────────
export const updatePerfume = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const {
      name, brand, country_of_origin, target_gender,
      price_tier, longevity, season_suitability,
      launch_year, description, accords
    } = req.body;

    await pool.query(`
      UPDATE Perfume SET
        name               = ?,
        brand              = ?,
        country_of_origin  = ?,
        target_gender      = ?,
        price_tier         = ?,
        longevity          = ?,
        season_suitability = ?,
        launch_year        = ?,
        description        = ?
      WHERE perfume_id = ?
    `, [
      name, brand, country_of_origin || null, target_gender,
      price_tier || null, longevity || null,
      season_suitability || null, launch_year || null,
      description || null, id
    ]);

    // updates accord links instead of ignoring them
    let newAccordAdded = false;
    if (accords && accords.length > 0) {
      await pool.query('DELETE FROM Perfume_Accord WHERE perfume_id = ?', [id]);
      for (const accordName of accords) {
        const [existing]: any = await pool.query(
          'SELECT accord_id FROM Accord WHERE accord_name = ?', [accordName]
        );
        if (existing.length === 0) {
          await pool.query('INSERT INTO Accord (accord_name) VALUES (?)', [accordName]);
          newAccordAdded = true;
        }
        const [[accord]]: any = await pool.query(
          'SELECT accord_id FROM Accord WHERE accord_name = ?', [accordName]
        );
        if (accord) {
          await pool.query(
            'INSERT IGNORE INTO Perfume_Accord (perfume_id, accord_id) VALUES (?, ?)',
            [id, accord.accord_id]
          );
        }
      }
    }

    // rebuilds the vector instead of nulling it
    if (newAccordAdded) {
      await rebuildAllVectors();
    } else {
      const vector = await buildFeatureVector(Number(id));
      await pool.query(
        'UPDATE Perfume SET feature_vector = ? WHERE perfume_id = ?',
        [JSON.stringify(vector), id]
      );
    }

    res.json({ success: true, message: 'Perfume updated' });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ── DELETE perfume ────────────────────────────────────────────
export const deletePerfume = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    await pool.query('DELETE FROM Perfume WHERE perfume_id = ?', [id]);

    res.json({ success: true, message: 'Perfume deleted' });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
};