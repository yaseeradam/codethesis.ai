import pool from '../db/connection';

export async function buildFeatureVector(perfumeId: number): Promise<number[]> {
  // Get the ordered accord index — same order used everywhere else
  const [accords]: any = await pool.query('SELECT accord_name FROM Accord ORDER BY accord_id');
  const accordIndex = accords.map((a: any) => a.accord_name);

  // Get this perfume's attributes + linked accords
  const [[perfume]]: any = await pool.query(
    `SELECT p.target_gender, p.price_tier, p.longevity, p.season_suitability,
            GROUP_CONCAT(a.accord_name) as accord_names
     FROM Perfume p
     LEFT JOIN Perfume_Accord pa ON p.perfume_id = pa.perfume_id
     LEFT JOIN Accord a ON pa.accord_id = a.accord_id
     WHERE p.perfume_id = ?
     GROUP BY p.perfume_id`,
    [perfumeId]
  );

  const perfumeAccords = perfume.accord_names ? perfume.accord_names.split(',') : [];
  const GENDERS = ['male', 'female', 'unisex'];
  const PRICE_TIERS = ['budget', 'moderate', 'high'];
  const LONGEVITY = ['light', 'moderate', 'strong'];
  const SEASONS = ['spring', 'summer', 'fall', 'winter'];

  const vector: number[] = [];
  for (const a of accordIndex) vector.push(perfumeAccords.includes(a) ? 1 : 0);
  for (const g of GENDERS) vector.push(perfume.target_gender === g ? 1 : 0);
  for (const p of PRICE_TIERS) vector.push(perfume.price_tier === p ? 1 : 0);
  for (const l of LONGEVITY) vector.push(perfume.longevity === l ? 1 : 0);
  for (const s of SEASONS) vector.push(perfume.season_suitability === s ? 1 : 0);

  return vector;
}

export async function rebuildAllVectors() {
  const [perfumes]: any = await pool.query('SELECT perfume_id FROM Perfume');
  for (const p of perfumes) {
    const vector = await buildFeatureVector(p.perfume_id);
    await pool.query('UPDATE Perfume SET feature_vector = ? WHERE perfume_id = ?', [JSON.stringify(vector), p.perfume_id]);
  }
}