console.log("Routes file loaded")
import express from 'express';
import cors    from 'cors';
import dotenv  from 'dotenv';
import './db/connection';
import routes  from './routes';
import { seedAdminIfNotExists } from './db/seedAdmin';

dotenv.config();

const app  = express();
const PORT = process.env.PORT || 5000;

app.use(cors({
  origin: [
    'http://localhost:3000',
    'https://ai-perfume-recommender.vercel.app',  
    /\.vercel\.app$/  // allows all vercel preview URLs
  ],
  credentials: true
}));
app.use(express.json()); 
app.use('/api', routes);

app.get('/', (req, res) => {
  res.json({ message: 'Perfume Recommender API is running' });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});