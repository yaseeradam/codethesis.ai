#!/bin/sh
# this file is an entry point script that runs the python scripts to seed and precompute vectors only if the db is empty
echo "Waiting for database..."
sleep 5

echo "Checking if database needs seeding.."
COUNT = $(python3 -c "
import mysqlconnector, od
conn = mysql.connector.connect(
    host = os.environ['DB_HOST'],
    user = os.environ['DB_USER'],
    password = os.environ['DB_PASSWORD'],
    database = os.environ['DB_NAME'],
    port = int(os.environ.get('DB_PORT', 3306))
)
cursor = conn.cursor()
cursor.execute('SELECT COUNT(*) FROM Perfume')
print (cursor.fetchone()[0])
conn.close()    
" 2>/dev/null || echo "0")

if ["$COUNT" = "0"]: then 
    echo "Database is emoty. Running seed script..."
    cd /database && python3 seed.py
    echo "Running precompute script..."
    python3 precompute_vectors.py
    echo "Database seeded successfully!"
else 
    echo "Database already has $COUNT perfumes. Skipping seed."
fi
    
echo "Starting backend server..."
exec node dist/index.js