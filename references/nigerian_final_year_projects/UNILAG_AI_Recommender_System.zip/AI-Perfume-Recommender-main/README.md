# ScentMatch — AI-Based Perfume Recommendation Engine

A full-stack AI-powered perfume recommendation system that uses content-based filtering and cosine similarity to match users with fragrances from a database of over 23,000 perfumes.

**Live Demo:** https://ai-perfume-recommender.vercel.app

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 19, TypeScript, Vite |
| Backend | Node.js, Express.js, TypeScript |
| Database | MySQL 8.0 |
| Algorithm | Python 3 — Cosine Similarity |
| Authentication | JWT + bcrypt |
| Deployment | Vercel (frontend), Railway (backend + database) |
| Containerization | Docker |

---

## Project Structure

```
perfumeRecommender/
├── frontend/                  # React + Vite + TypeScript
│   ├── src/
│   │   ├── pages/
│   │   │   ├── HomePage.tsx
│   │   │   ├── QuizPage.tsx
│   │   │   ├── ResultsPage.tsx
│   │   │   ├── AdminPage.tsx
│   │   │   └── LoginPage.tsx
│   │   ├── components/
│   │   │   ├── Navbar.tsx
│   │   │   ├── RecommendationCard.tsx
│   │   │   ├── Spinner.tsx
│   │   │   └── ProtectedRoute.tsx
│   │   └── utils/
│   │       └── auth.ts
│   └── vercel.json
├── backend/                   # Node.js + Express + TypeScript
│   ├── src/
│   │   ├── controllers/
│   │   │   ├── recommendController.ts
│   │   │   ├── adminController.ts
│   │   │   └── authController.ts
│   │   ├── middleware/
│   │   │   └── auth.ts
│   │   ├── routes/
│   │   │   └── index.ts
│   │   └── db/
│   │       └── connection.ts
│   └── recommender.py         # Cosine similarity engine
└── database/
    ├── schema.sql             # Database schema
    ├── seed.py                # Data seeding script
    └── precompute_vectors.py  # Feature vector precomputation
```

---

## Prerequisites

- Node.js v18+
- Python 3.9+
- MySQL 8.0+
- pip (Python package manager)

---

## Local Setup Instructions

### 1. Clone the Repository

```bash
git clone https://github.com/YOURUSERNAME/AI-Perfume-Recommender.git
cd AI-Perfume-Recommender
```

### 2. Database Setup

Log into MySQL and run the schema:

```bash
mysql -u your_user -p < database/schema.sql
```

Create a MySQL user for the project:

```sql
CREATE USER 'perfume_user'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON perfume_db.* TO 'perfume_user'@'localhost';
FLUSH PRIVILEGES;
```

### 3. Seed the Database

Place `fra_cleaned.csv` in the `database/` folder, then:

```bash
pip install pandas mysql-connector-python
cd database
python seed.py
python precompute_vectors.py
```

### 4. Backend Setup

```bash
cd backend
npm install
```

Create a `.env` file:

```env
DB_HOST=localhost
DB_USER=perfume_user
DB_PASSWORD=your_password
DB_NAME=perfume_db
PORT=5000
JWT_SECRET=your_secret_key
```

Insert admin credentials:

```bash
node -e "const bcrypt = require('bcryptjs'); bcrypt.hash('admin123', 10).then(h => { require('fs').writeFileSync('hash.txt', h); })"
```

Then in MySQL:

```sql
USE perfume_db;
INSERT INTO Admin (username, password) VALUES ('admin', 'HASH_FROM_HASH.TXT');
```

Start the backend:

```bash
npm run dev
```

### 5. Frontend Setup

```bash
cd frontend
npm install
npm run dev
```

Visit `http://localhost:3000`

---

## Docker Setup (Alternative)

```bash
docker-compose up --build
```

This starts all three services (frontend, backend, MySQL) in containers automatically.

---

## API Endpoints

### Public

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/recommend` | Get perfume recommendations |
| POST | `/api/auth/login` | Admin login |

### Protected (Requires JWT)

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/perfumes` | Get all perfumes (paginated) |
| GET | `/api/perfumes/:id` | Get single perfume |
| POST | `/api/perfumes` | Create perfume |
| PUT | `/api/perfumes/:id` | Update perfume |
| DELETE | `/api/perfumes/:id` | Delete perfume |
| PUT | `/api/auth/change-password` | Change admin password |

---

## How the Recommendation Algorithm Works

1. User submits preferences (accords, gender, budget, longevity, season)
2. Preferences are encoded into a 97-dimensional feature vector
3. All 23,846 perfume vectors are loaded from the database
4. Cosine similarity is computed between the user vector and every perfume vector
5. Top N results are returned ranked by similarity score

**Vector dimensions:**
- 84 accord dimensions (multi-hot encoded)
- 3 gender dimensions (one-hot encoded)
- 3 price tier dimensions (one-hot encoded)
- 3 longevity dimensions (one-hot encoded)
- 4 season dimensions (one-hot encoded)
- **Total: 97 dimensions**

---

## Deployment

### Frontend → Vercel
1. Import GitHub repo on Vercel
2. Set root directory to `frontend`
3. Deploy

### Backend + Database → Railway
1. Create new project from GitHub repo
2. Set root directory to `backend`
3. Add MySQL database service
4. Set environment variables
5. Deploy

---

## Default Admin Credentials

```
Username: admin
Password: admin123
```

Change the password after first login via the Admin Panel.

---

## Dataset

- **Source:** Fragrantica (fra_cleaned.csv)
- **Size:** 23,846 perfumes
- **Fields used:** Name, Brand, Gender, Top/Middle/Base notes, Main accords (x5), Rating, Year, Country
- **Fields generated:** price_tier, longevity, season_suitability (auto-derived from dataset)
