# User Manual — ScentMatch AI Perfume Recommender

**Version:** 1.0
**Live URL:** https://ai-perfume-recommender.vercel.app

---

## Introduction

ScentMatch is an AI-powered perfume recommendation system that helps you discover fragrances perfectly matched to your personal preferences. By answering a short quiz about your scent preferences, budget, and lifestyle, our system analyses over 23,000 perfumes and recommends your top matches with similarity scores and explanations.

---

## Getting Started

### Accessing the System

Open your browser and visit:
```
https://ai-perfume-recommender.vercel.app
```

The system works on all modern browsers including Chrome, Firefox, Safari, and Edge. It is also fully optimised for mobile devices.

---

## For Regular Users

### Step 1 — Home Page

When you first visit the site you will see the home page displaying:

- A welcome message and brief description of the system
- Key statistics (23,000+ fragrances, 84 scent families, AI-powered)
- A **"Find My Fragrance"** button to begin

Click **"Find My Fragrance"** to start the quiz.

---

### Step 2 — The Quiz (Step 1 of 2): Scent Families

You will be presented with 16 scent family options represented by emoji tiles:

| Scent | Description |
|---|---|
| 🌸 Floral | Rose, jasmine, and flower-based scents |
| 🪵 Woody | Sandalwood, cedar, and earthy wood tones |
| 🍋 Citrus | Fresh lemon, orange, and bergamot notes |
| 💨 Fresh | Clean, airy, and light scents |
| 🌙 Oriental | Rich, exotic, and mysterious blends |
| 🤍 Musky | Soft, sensual, and skin-like warmth |
| 🍦 Vanilla | Sweet, creamy, and comforting notes |
| 🍫 Gourmand | Dessert-like, edible-smelling fragrances |
| 🌊 Aquatic | Ocean, sea breeze, and water-inspired |
| 🌶️ Spicy | Pepper, clove, and warming spice notes |
| 🌿 Aromatic | Herbal, green, and botanical scents |
| 🍑 Fruity | Sweet fruit and tropical notes |
| 🫧 Powdery | Soft, talcum-like, and elegant |
| 🟠 Amber | Warm, resinous, and golden tones |
| 🤎 Leather | Bold, smoky, and sophisticated |
| 🍃 Green | Freshly cut grass and leafy scents |

**Instructions:**
- Click on any tile to select it (it will highlight in blue)
- Click again to deselect
- Select as many as you like — the more you select, the broader your matches
- You must select at least one to proceed
- The counter at the bottom shows how many you have selected

Click **"Next →"** when done.

---

### Step 3 — The Quiz (Step 2 of 2): Style Preferences

Fill in four preference sections:

**Gender**
- 👩 Feminine — traditionally female-oriented fragrances
- 👨 Masculine — traditionally male-oriented fragrances
- 🧑 Unisex — fragrances suitable for anyone

**Budget**
- 💰 Budget — affordable, everyday fragrances
- 💳 Moderate — mid-range, quality fragrances
- 💎 High End — luxury and designer fragrances

**Longevity (How long should it last?)**
- 🌬️ Light — subtle, fades within a few hours
- ⏱️ Moderate — lasts 4-6 hours
- 💪 Long Lasting — stays noticeable all day

**Season**
- 🌸 Spring — fresh and floral
- ☀️ Summer — light and refreshing
- 🍂 Fall — warm and spicy
- ❄️ Winter — rich and heavy

Select one option from each section, then click **"Find My Fragrances ✨"**.

---

### Step 4 — Your Results

After a few seconds the results page displays your top 10 matched fragrances. Each card shows:

- **Rank badge** — #1 (gold), #2 (silver), #3 (bronze), and so on
- **Perfume name and brand**
- **Star rating** — average community rating from Fragrantica
- **Match score** — percentage showing how closely it matches your preferences (shown as a circular ring)
- **Tags** — gender, budget, longevity, and season
- **Explanation** — a personalised reason why this perfume was recommended for you

**Tips for reading results:**
- A score above 70% is an excellent match
- A score above 50% is a good match
- The explanation tells you exactly which of your preferences were matched

---

### Retaking the Quiz

To try different preferences:
- Click **"← Retake Quiz"** at the top of the results page
- Or click **"Try Different Preferences"** at the bottom
- Or click **"Find Fragrance"** in the navigation bar

---

## For Admin Users

The admin panel allows authorised users to manage the perfume database.

### Accessing the Admin Panel

1. Click **"Admin Login"** in the top right of the navigation bar
2. Or visit: `https://ai-perfume-recommender.vercel.app/admin/login`

**Default credentials:**
```
Username: admin
Password: admin123
```

---

### Admin Dashboard Overview

The admin panel shows:
- Total number of perfumes in the database
- A searchable, paginated table of all perfumes
- Buttons to add, edit, and delete perfumes

---

### Searching Perfumes

Type a perfume name or brand in the search box and click **"Search"**. Results update instantly. Click **"Clear"** to reset the search.

---

### Adding a New Perfume

1. Click the **"+ Add Perfume"** button
2. Fill in the form:
   - **Name** (required) — perfume name
   - **Brand** (required) — brand name
   - **Gender** (required) — male / female / unisex
   - **Price Tier** — budget / moderate / high
   - **Longevity** — light / moderate / strong
   - **Season** — spring / summer / fall / winter
   - **Country** — country of origin
   - **Launch Year** — year released
   - **Accords** — comma-separated list (e.g. floral, woody, citrus)
   - **Description** — optional description
3. Click **"Create Perfume"**

---

### Editing a Perfume

1. Find the perfume in the table (use search if needed)
2. Click the **"Edit"** button on that row
3. Update any fields in the form
4. Click **"Save Changes"**

---

### Deleting a Perfume

1. Find the perfume in the table
2. Click the **"Delete"** button
3. Confirm the deletion in the popup dialog

**Warning:** Deletion is permanent and cannot be undone.

---

### Changing Your Password

1. Click the **"🔑 Change Password"** button in the admin header
2. Enter your current password
3. Enter and confirm your new password (minimum 6 characters)
4. Click **"Change Password"**

---

### Logging Out

Click the **"Logout"** button in the admin header or navigation bar. You will be redirected to the login page. Your session expires automatically after 8 hours.

---

## Troubleshooting

| Issue | Solution |
|---|---|
| Page shows blank on reload | Refresh the page — this has been fixed in the latest version |
| Quiz submit button is greyed out | Make sure all fields in Step 2 are selected |
| No results returned | Try selecting more scent families for broader matches |
| Admin login fails | Check your username and password — they are case-sensitive |
| Slow recommendation results | The AI is analysing 23,000+ perfumes — please allow up to 10 seconds |

---

## Browser Compatibility

| Browser | Supported |
|---|---|
| Google Chrome 90+ | ✅ |
| Mozilla Firefox 88+ | ✅ |
| Safari 14+ | ✅ |
| Microsoft Edge 90+ | ✅ |
| Internet Explorer | ❌ |
