# Self-Contained Zero-Dependency Backend Server
# Requires Python 3.8+ (Uses standard library: http.server and sqlite3)

import http.server
import socketserver
import json
import sqlite3
import os

PORT = 8000
DB_FILE = 'database.db'

def get_db():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

class ProjectHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/' or self.path == '/index.html':
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.end_headers()
            with open('static/index.html', 'rb') as f:
                self.wfile.write(f.read())
            return
            
        elif self.path == '/api/rooms':
            conn = get_db()
            rooms = conn.execute('''
                SELECT r.id, r.room_number, r.bed_capacity, r.occupied_beds, r.status, h.name as hostel_name 
                FROM rooms r 
                JOIN hostels h ON r.hostel_id = h.id
            ''').fetchall()
            conn.close()
            
            data = [dict(row) for row in rooms]
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(data).encode('utf-8'))
            return
            
        elif self.path == '/api/tickets':
            conn = get_db()
            tickets = conn.execute('SELECT * FROM maintenance_tickets ORDER BY id DESC').fetchall()
            conn.close()
            
            data = [dict(row) for row in tickets]
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(data).encode('utf-8'))
            return
            
        super().do_GET()

    def do_POST(self):
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length)
        body = json.loads(post_data.decode('utf-8')) if post_data else {}

        if self.path == '/api/allocate':
            room_id = body.get('room_id')
            conn = get_db()
            cursor = conn.cursor()
            
            # Transactional row-level check
            cursor.execute('SELECT bed_capacity, occupied_beds FROM rooms WHERE id = ?', (room_id,))
            room = cursor.fetchone()
            
            if not room:
                conn.close()
                self.send_response(404)
                self.end_headers()
                self.wfile.write(json.dumps({'error': 'Room not found'}).encode('utf-8'))
                return
                
            if room['occupied_beds'] >= room['bed_capacity']:
                conn.close()
                self.send_response(400)
                self.end_headers()
                self.wfile.write(json.dumps({'error': 'Room is already full!'}).encode('utf-8'))
                return
                
            new_occupied = room['occupied_beds'] + 1
            new_status = 'FULL' if new_occupied >= room['bed_capacity'] else 'AVAILABLE'
            
            cursor.execute('UPDATE rooms SET occupied_beds = ?, status = ? WHERE id = ?', (new_occupied, new_status, room_id))
            cursor.execute('INSERT INTO allocations (user_id, room_id, bed_number, academic_session) VALUES (?, ?, ?, ?)',
                           (2, room_id, new_occupied, '2025/2026'))
            conn.commit()
            conn.close()
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({'status': 'SUCCESS', 'bed_number': new_occupied}).encode('utf-8'))
            return

        elif self.path == '/api/tickets':
            category = body.get('category', 'General')
            description = body.get('description', '')
            room_number = body.get('room_number', 'Block A - Room 101')
            
            conn = get_db()
            cursor = conn.cursor()
            cursor.execute('INSERT INTO maintenance_tickets (user_id, room_number, category, description) VALUES (?, ?, ?, ?)',
                           (2, room_number, category, description))
            conn.commit()
            conn.close()
            
            self.send_response(201)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({'status': 'SUCCESS'}).encode('utf-8'))
            return

print(f"[STARTING] CodeThesis Project Server on port {PORT}...")
print(f"Open http://localhost:{PORT} in your web browser.")
with socketserver.TCPServer(("", PORT), ProjectHandler) as httpd:
    httpd.serve_forever()
