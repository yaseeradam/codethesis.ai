# Automated Hostel Allocation and Facility Management System
### Complete Working Software & Supervisor Defense Guide
**Department:** Computer Science  
**Institution:** Federal University of Technology, Akure  
**Engine:** CodeThesis Turnkey Software Builder  

---

## 🚀 How to Run the Software (For Defense Presentation)
1. Double-click the **`run_project.bat`** file in this folder.
2. The script will automatically initialize the local **SQLite database**, pre-populate all rooms and mock student records, and open the live web app in your default browser at **http://localhost:8000**.
3. **No complicated pip installs or terminal commands required!**

---

## 🔑 Demo Login Credentials
* **Hostel Administrator Account**:
  * Email: `admin@codethesis.edu`
  * Password: `admin123`
  * Capabilities: View occupancy analytics, approve/reject allocations, manage maintenance tickets.
* **Student Account**:
  * Email: `chidi@codethesis.edu`
  * Password: `student123`
  * Capabilities: Browse available hostel rooms, reserve bedspaces, view allocation slip, log maintenance issues.

---

## 🛠️ Architecture & Tech Stack
* **Frontend**: HTML5, Responsive Tailwind CSS, Vanilla JavaScript SPA.
* **Backend**: Lightweight Python HTTP Server (`server.py`) with RESTful JSON endpoints.
* **Database**: Embedded relational SQLite3 (`database.db`) with ACID row-level locking.
