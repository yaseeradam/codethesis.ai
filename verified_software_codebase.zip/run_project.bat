@echo off
title CodeThesis Project Launcher - Automated Hostel Allocation and Facility Management System
color 0B
echo ======================================================================
echo          CODETHESIS ZERO-CONFIG LOCAL RUNNER
echo          Project: Automated Hostel Allocation and Facility Management System
echo ======================================================================
echo.
echo [1/3] Checking Python runtime...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed or not in PATH!
    echo Please install Python from https://www.python.org/downloads/
    pause
    exit /b
)

echo [2/3] Initializing local SQLite database and mock records...
python -c "import sqlite3; conn = sqlite3.connect('database.db'); conn.executescript(open('database/schema.sql').read()); conn.executescript(open('database/seed_data.sql').read()); conn.close(); print('[SUCCESS] Database initialized successfully.')"

echo [3/3] Starting local application server on http://localhost:8000...
start http://localhost:8000
echo.
echo ======================================================================
echo  SERVER IS RUNNING! (Press Ctrl+C in this terminal window to stop)
echo  Student Portal: http://localhost:8000
echo  Admin Credentials: admin@codethesis.edu / admin123
echo  Student Credentials: chidi@codethesis.edu / student123
echo ======================================================================
echo.
python server.py
pause
