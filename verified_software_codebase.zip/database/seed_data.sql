-- Pre-seeded Mock Records for Defense
INSERT INTO users (matric_number, full_name, email, password, gender, level, role) VALUES
('ADMIN/001', 'Hostel Hall Master', 'admin@codethesis.edu', 'admin123', 'Male', 500, 'admin'),
('FUTA/CSC/20/4182', 'Chidi Eze', 'chidi@codethesis.edu', 'student123', 'Male', 400, 'student'),
('FUTA/CSC/20/1943', 'Amina Yusuf', 'amina@codethesis.edu', 'student123', 'Female', 400, 'student');

INSERT INTO hostels (name, gender_designation, total_capacity) VALUES
('Hall 1 (Jaja Hall)', 'Male', 120),
('Hall 2 (Moremi Hall)', 'Female', 140),
('Hall 3 (Postgraduate Wing)', 'Mixed', 80);

INSERT INTO rooms (hostel_id, room_number, bed_capacity, occupied_beds, status) VALUES
(1, 'Block A - Room 101', 4, 2, 'AVAILABLE'),
(1, 'Block A - Room 102', 4, 4, 'FULL'),
(1, 'Block B - Room 201', 4, 1, 'AVAILABLE'),
(2, 'Block C - Room 101', 4, 3, 'AVAILABLE'),
(2, 'Block C - Room 102', 4, 4, 'FULL');

INSERT INTO allocations (user_id, room_id, bed_number, academic_session, status) VALUES
(2, 1, 1, '2025/2026', 'CONFIRMED');

INSERT INTO maintenance_tickets (user_id, room_number, category, description, status) VALUES
(2, 'Block A - Room 101', 'Electrical', 'Ceiling fan regulator not rotating on speeds 3 and 4.', 'IN_PROGRESS');
